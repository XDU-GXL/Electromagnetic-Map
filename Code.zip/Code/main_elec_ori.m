clear;
clc;
close all;
set(0,'defaultfigurecolor','w')%显示背景设置为白色
%导入原始数据
opts = spreadsheetImportOptions("NumVariables", 5);
opts.VariableTypes = ["double", "double", "double", "double", "double"];
dataset = readtable(".\map.xls", opts, "UseExcel", false);
dataset = table2array(dataset(2:end,:));

%原始数据的处理，仿真时坐标原点为(610819,5629814)
x0=dataset(:,2); %x坐标
y0=dataset(:,3); %y坐标
b0=dataset(:,4); %RSRP值

%原电磁地图的绘制(三维图加二维图）
figure
%subplot(2,2,1);
uij=20:20:200*20;
vij=20:20:200*20; %长宽4000米，间隔长度为20 米
[xi,yj]=meshgrid(uij,vij);
F = scatteredInterpolant(x0,y0,b0,'linear'); %共两千多数据，其它栅格用立方插值补齐(经测试，这里用任何方法都差不多，对地图影响不大)
z2 = F(xi,yj);
[Dx,Dy]=gradient(z2,20,20); %梯度
%surf(xi,yj,-100*ones(size(z2)),z2);%用立体图的形式展示
%hold on
%surf(xi,yj,z2);%用立体图的形式展示
%shading flat
%c=colorbar; %显示图例
%c.Label.String = 'RSRP/dBm';
%title( '原电磁地图' )
%contour(xi,yj,z2)
 %hold on
% quiver(xi,yj,Dx,Dy); %梯度箭头图
h=pcolor(xi,yj,z2); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z2);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP(dBm)';

% load('x20.mat');  
% load('b20.mat'); 

