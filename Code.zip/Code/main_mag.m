load('100_.mat'); 
load('longtitude.mat'); 
load('latitude.mat'); 
% whos;380
x0 = longitude(:, 1);
y0 = latitude(:, 1); 
b0 = round(distortedData(:, 1) .* 0.1) / 100;
uij=100:0.1:109;
vij=30:0.1:36;
[xi,yj]=meshgrid(uij,vij);

N=380; 
[sizex,~]=size(x0);
idx = randperm(sizex, N); %在data的长度中随机选取N个数据作为随机索引
sorted_data = sort(idx); %将随机索引按照从小到大的顺序排序
x(:,1) = x0(idx); %按照排序后的随机索引在data中索引数据
x(:,2) = y0(idx);
b=b0(idx); %随机样本点的RSRP值

figure
% subplot(1,2,1);
F = scatteredInterpolant(x0,y0,b0,'linear'); %共两千多数据，其它栅格用立方插值补齐(经测试，这里用任何方法都差不多，对地图影响不大)
z2 = F(xi,yj);
[Dx,Dy]=gradient(z2,20,20); %梯度
surf(xi,yj,-100*ones(size(z2)),z2);%用立体图的形式展示
hold on
surf(xi,yj,z2);%用立体图的形式展示
shading flat
c=colorbar; %显示图例
c.Label.String = 'Strength (uT)';
% title( '原电磁地图' ) 
% subplot(1,2,2);
% contour(xi,yj,z2)
%  hold on
% quiver(xi,yj,Dx,Dy); %梯度箭头图
% h=pcolor(xi,yj,z2); %用热度图的形式展示
% set(h,'edgecolor','none'); %去掉网格，平滑热度图
% [c,h]=contourf(xi,yj,z2);%加入等高线
% c=colorbar; %显示图例
% c.Label.String = 'RSRP/dBm';

figure
subplot(2,2,1)
% 开始计时
% tic;
F = scatteredInterpolant(x(:,1),x(:,2),b,'nearest'); 
z1 = F(xi,yj);
 % 定义噪声功率（方差）
noise_power =0; % 假设噪声功率为0.1
% 生成随机噪声  
noise = sqrt(noise_power) * randn(size(z1)); % 生成与矩阵大小相同的随机噪声
% 添加噪声
z1 = z1 + noise; % 将随机噪声添加到随机矩阵中
h=pcolor(xi,yj,z1); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z1);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP(dBm)';
title( 'NN' )
RMSE_CC(xi, yj, x0, y0, b0, z1,x);
% % 停止计时并输出结果
% elapsed_time = toc;
% disp(['Elapsed time: ', num2str(elapsed_time), ' seconds']);

subplot(2,2,2)
% tic;
F = scatteredInterpolant(x(:,1),x(:,2),b,'natural'); 
z2 = F(xi,yj);  
h=pcolor(xi,yj,z2); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z2);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP(dBm)';
title( 'N' )
% 停止计时并输出结果
% elapsed_time = toc;
% disp(['Elapsed time: ', num2str(elapsed_time), ' seconds']);
 % 定义噪声功率（方差）
noise_power =0; % 假设噪声功率为0.1
% 生成随机噪声  
noise = sqrt(noise_power) * randn(size(z2)); % 生成与矩阵大小相同的随机噪声
% 添加噪声
z2 = z2 + noise; % 将随机噪声添加到随机矩阵中
RMSE_CC(xi, yj, x0, y0, b0, z2,x);

subplot(2,2,3);
% tic;
z3=IDW(x(:,1),x(:,2),b,xi,yj,2);
h=pcolor(xi,yj,z3); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z3);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP(dBm)';
title( 'IDW' )
% 停止计时并输出结果
% elapsed_time = toc;
% disp(['Elapsed time: ', num2str(elapsed_time), ' seconds']);
 % 定义噪声功率（方差）
noise_power =0; % 假设噪声功率为0.1
% 生成随机噪声  
noise = sqrt(noise_power) * randn(size(z3)); % 生成与矩阵大小相同的随机噪声
% 添加噪声
z3 = z3 + noise; % 将随机噪声添加到随机矩阵中
RMSE_CC(xi, yj, x0, y0, b0, z3,x);

subplot(2,2,4);
% tic;
z4=MSM(x(:,1),x(:,2),b,xi,yj);
h=pcolor(xi,yj,z4); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z4);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP(dBm)';
title( 'MSM' )
% 停止计时并输出结果
% elapsed_time = toc;          
% disp(['Elapsed time: ', num2str(elapsed_time), ' seconds']);
 % 定义噪声功率（方差）
noise_power =0; % 假设噪声功率为0.1
% 生成随机噪声  
noise = sqrt(noise_power) * randn(size(z4)); % 生成与矩阵大小相同的随机噪声
% 添加噪声
z4 = z4 + noise; % 将随机噪声添加到随机矩阵中
RMSE_CC(xi, yj, x0, y0, b0, z4,x  );


