% 开始计时
clear;
clc;
close all;
set(0,'defaultfigurecolor','w')%显示背景设置为白色
%导入原始数据
opts = spreadsheetImportOptions("NumVariables", 5);
opts.VariableTypes = ["double", "double", "double", "double", "double"];
dataset = readtable(".\map.xls", opts, "UseExcel", false);
dataset = table2array(dataset(2:end,:));

%原始数据的处理，仿真时坐标原点为(610819,5629814)
x0=dataset(:,2); %x坐标
y0=dataset(:,3); %y坐标
b0=dataset(:,4); %RSRP值

%随机部署400个样本点
load('x-.mat');  
load('b-.mat'); 

%IDW插值图像
uij=20:20:200*20;
vij=20:20:200*20;
[xi,yj]=meshgrid(uij,vij);

subplot(2,3,1)
z1=IDW(x(:,1),x(:,2),b,xi,yj,0.2);
h=pcolor(xi,yj,z1); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z1);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'IDW重构结果p=0.2' )

subplot(2,3,2)
z2=IDW(x(:,1),x(:,2),b,xi,yj,0.5);
h=pcolor(xi,yj,z2); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z2);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'IDW重构结果p=0.5' )

subplot(2,3,3)
z3=IDW(x(:,1),x(:,2),b,xi,yj,1);
h=pcolor(xi,yj,z3); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z3);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'IDW重构结果p=1' )

subplot(2,3,4)
z4=IDW(x(:,1),x(:,2),b,xi,yj,1.3);
h=pcolor(xi,yj,z4); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z4);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'IDW重构结果p=1.3' )

subplot(2,3,5)
z5=IDW(x(:,1),x(:,2),b,xi,yj,1.5);
h=pcolor(xi,yj,z5); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z5);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'IDW重构结果p=1.5' )

subplot(2,3,6)
z6=IDW(x(:,1),x(:,2),b,xi,yj,2);
h=pcolor(xi,yj,z6); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z6);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'IDW重构结果p=2' )

subplot(1,3,1)
z7=IDW(x(:,1),x(:,2),b,xi,yj,2.5);
h=pcolor(xi,yj,z7); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z7);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'IDW重构结果p=2.5' )

subplot(1,3,1)
z8=IDW(x(:,1),x(:,2),b,xi,yj,0);
h=pcolor(xi,yj,z8); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z8);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'IDW重构结果p=0' )

%{
figure
subplot(1,3,1)
z7=IDW(x(:,1),x(:,2),b,xi,yj,3);
h=pcolor(xi,yj,z7); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z7);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'IDW重构结果p=3' )

subplot(1,3,2)
z8=IDW(x(:,1),x(:,2),b,xi,yj,7);
h=pcolor(xi,yj,z8); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z8);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'IDW重构结果p=7' )

subplot(1,3,3)
z9=IDW(x(:,1),x(:,2),b,xi,yj,14);
h=pcolor(xi,yj,z9); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z9);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'IDW重构结果p=14' )
%{
%计算均方根误差
RMSE_CC(xi, yj, x0, y0, b0, z1, 0.2);
RMSE_CC(xi, yj, x0, y0, b0, z2, 0.5);
RMSE_CC(xi, yj, x0, y0, b0, z3, 1);
RMSE_CC(xi, yj, x0, y0, b0, z4, 1.3);
RMSE_CC(xi, yj, x0, y0, b0, z5, 1.7);
RMSE_CC(xi, yj, x0, y0, b0, z6, 2);
RMSE_CC(xi, yj, x0, y0, b0, z7, 3);
RMSE_CC(xi, yj, x0, y0, b0, z8, 7);
RMSE_CC(xi, yj, x0, y0, b0, z9, 14);
%}
%}

figure;
hold on;
CDF(xi, yj, x0, y0, b0, z8, 0, '-',	'r','v');
CDF(xi, yj, x0, y0, b0, z2, 0.5, '-','k','+');
CDF(xi, yj, x0, y0, b0, z3, 1, '-','b','o');
CDF(xi, yj, x0, y0, b0, z5, 1.5, '-','k','*');
CDF(xi, yj, x0, y0, b0, z6, 2, '-','g','none ');
CDF(xi, yj, x0, y0, b0, z7, 2.5, '-','b','none');
set(gca,'box','off')
legend( 's=0','s=0.5', 's=1', 's=1.5', 's=2', 's=2.5' );
hold off;

%{
figure;
hold on;
CDF(xi, yj, x0, y0, b0, z6, 2, '-','r');
CDF(xi, yj, x0, y0, b0, z7, 3, '--','k');
CDF(xi, yj, x0, y0, b0, z8, 7, ':','m');
CDF(xi, yj, x0, y0, b0, z9, 14, '-','b');
legend('s=2','s=3','s=7','s=14');
hold off;
%}