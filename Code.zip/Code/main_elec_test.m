clear;
clc;
close all;
set(0,'defaultfigurecolor','w')%显示背景设置为白色
%导入原始数据
opts = spreadsheetImportOptions("NumVariables", 5);
opts.VariableTypes = ["double", "double", "double", "double", "double"];
dataset = readtable(".\map.xls", opts, "UseExcel", false);
dataset = table2array(dataset(2:end,:));

%原始数据的处理，仿真时坐标原点为(610819,5629814)
x0=dataset(:,2); %x坐标
y0=dataset(:,3); %y坐标
b0=dataset(:,4); %RSRP值

load('b20.mat');
load('x20.mat');

% N=288; 
% [sizex,~]=size(x0);
% idx = randperm(sizex, N); %在data的长度中随机选取N个数据作为随机索引
% sorted_data = sort(idx); %将随机索引按照从小到大的顺序排序
% x(:,1) = x0(idx); %按照排序后的随机索引在data中索引数据
% x(:,2) = y0(idx);
% b=b0(idx); %随机样本点的RSRP值

uij=20:20:200*20;
vij=20:20:200*20;
[xi,yj]=meshgrid(uij,vij);

subplot(2,2,1)
% 开始计时
tic;
F = scatteredInterpolant(x(:,1),x(:,2),b,'nearest'); 
z1 = F(xi,yj);
 % 定义噪声功率（方差）
noise_power =0; % 假设噪声功率为0.1
% 生成随机噪声  
noise = sqrt(noise_power) * randn(size(z1)); % 生成与矩阵大小相同的随机噪声
% 添加噪声
z1 = z1 + noise; % 将随机噪声添加到随机矩阵中

h=pcolor(xi,yj,z1); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z1);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'NN' )
RMSE_CC(xi, yj, x0, y0, b0, z1,x);
% 停止计时并输出结果
elapsed_time = toc;
disp(['Elapsed time: ', num2str(elapsed_time), ' seconds']);

subplot(2,2,2)
% tic;
F = scatteredInterpolant(x(:,1),x(:,2),b,'natural'); 
z2 = F(xi,yj);  
h=pcolor(xi,yj,z2); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z2);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'N' )
% 停止计时并输出结果
elapsed_time = toc;
disp(['Elapsed time: ', num2str(elapsed_time), ' seconds']);
 % 定义噪声功率（方差）
noise_power =0; % 假设噪声功率为0.1
% 生成随机噪声  
noise = sqrt(noise_power) * randn(size(z2)); % 生成与矩阵大小相同的随机噪声
% 添加噪声
z2 = z2 + noise; % 将随机噪声添加到随机矩阵中
RMSE_CC(xi, yj, x0, y0, b0, z2,x);

subplot(2,2,3);
tic;
z3=IDW(x(:,1),x(:,2),b,xi,yj,2);
h=pcolor(xi,yj,z3); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z3);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'IDW' )
% 停止计时并输出结果
elapsed_time = toc;
disp(['Elapsed time: ', num2str(elapsed_time), ' seconds']);
 % 定义噪声功率（方差）
noise_power =0; % 假设噪声功率为0.1
% 生成随机噪声  
noise = sqrt(noise_power) * randn(size(z3)); % 生成与矩阵大小相同的随机噪声
% 添加噪声
z3 = z3 + noise; % 将随机噪声添加到随机矩阵中
RMSE_CC(xi, yj, x0, y0, b0, z3,x);

subplot(2,2,4);
tic;
z4=MSM(x(:,1),x(:,2),b,xi,yj);
h=pcolor(xi,yj,z4); %用热度图的形式展示
set(h,'edgecolor','none'); %去掉网格，平滑热度图
[c,h]=contourf(xi,yj,z4);%加入等高线
c=colorbar; %显示图例
c.Label.String = 'RSRP/dBm';
title( 'MSM' )
% 停止计时并输出结果
elapsed_time = toc;
disp(['Elapsed time: ', num2str(elapsed_time), ' seconds']);
 % 定义噪声功率（方差）
noise_power =0; % 假设噪声功率为0.1
% 生成随机噪声  
noise = sqrt(noise_power) * randn(size(z4)); % 生成与矩阵大小相同的随机噪声
% 添加噪声
z4 = z4 + noise; % 将随机噪声添加到随机矩阵中
RMSE_CC(xi, yj, x0, y0, b0, z4,x  );

d1=box(xi, yj, x0, y0, b0, z1);
d2=box(xi, yj, x0, y0, b0, z2);
d3=box(xi, yj, x0, y0, b0, z3);
d4=box(xi, yj, x0, y0, b0, z4);

figure;
boxplot([d1 d2 d3 d4],'whisker', 5,'Labels',{'NN','Natural','IDW','MSM'});
ylabel('AE(dbm)');


% figure;
% CDF(xi, yj, x0, y0, b0, z1,'-','r','v');
% hold on;
% CDF(xi, yj, x0, y0, b0, z2, '-','g','+');
% CDF(xi, yj, x0, y0, b0, z3, '-','b','o');
% CDF(xi, yj, x0, y0, b0, z4, '-','k','*');
% legend('NN', 'Natural', 'IDW', 'MSM');
% hold off;
