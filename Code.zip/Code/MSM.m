function Z=MSM(x,y,z,X,Y)
[xSize,~] = size(x);
[XRows,XCols] = size(X);
[zSize,~] = size(z);
 rr=1;
 n_count=0;
 Z = zeros(XRows, XCols);
 
% ���������뾶
radius = sqrt((X(1,1)-X(XRows ,XCols ))*(X(1,1)-X(XRows ,XCols ))/9+(Y(1,1)- Y(XRows ,XCols ))*(Y(1,1)-Y(XRows,XCols ))./9);

for i = 1:1:XRows
    %���ɾ������r(m0*m1*n1,n0)
    m = 1;
    for j = 1:1:XCols
        for k = 1:1:xSize
            DisArray(m) = sqrt((X(i,j) - x(k)) * (X(i,j) - x(k))+ (Y(i,j) - y(k)) * (Y(i,j) - y(k)));
            m = m + 1;
        end
    end
  
    %�����ֵ����
    n = 1;
    n1 = 1;
    rr = 1;
    for j = 1:1:XCols
        sum = 0.0;
        sum1 = 0.0;
        sum2 = 0.0;
       
        
   for k1 = 1:1:zSize
           if (DisArray(rr) == 0)
                index = mod(rr, zSize);
                if index == 0
                    Z(i, j) = z(26);
                else
                    Z(i,j)= z(index);
                end
                n_count = n_count + 1;
           end
                rr = rr + 1;
   end 

     
        for k = 1:1:zSize
            if DisArray(n1) == 0
                n1 = n1 + 1;
          continue
          else
            sum1 = ((radius - DisArray(n1)) / (radius * DisArray(n1)))* ((radius - DisArray(n1)) / (radius * DisArray(n1)))+ sum1;
            n1 = n1 + 1;
           end
        end
        for k = 1:1:zSize
            if DisArray(n) == 0
                n = n + 1;
          continue
            else
            sum = z(k)* ((radius - DisArray(n)) / (radius * DisArray(n)))* ((radius - DisArray(n)) / (radius * DisArray(n)))/ sum1 + sum;
            sum2 = ((radius - DisArray(n)) / (radius * DisArray(n)))* ((radius - DisArray(n)) / (radius * DisArray(n)))/ sum1 + sum2;
            n = n + 1;
            end
        end
        Z(i,j) = sum / sum2;
       end
   
end
end
