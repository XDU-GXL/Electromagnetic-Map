main_elec_test.m: Main function for reconstructing electromagnetic maps using Nearest Neighbor, Natural Neighbor, and two Inverse Distance Weighting methods, and testing their RMSE and CC performance.

main_mag.m: Main function for reconstructing magnetic maps using Nearest Neighbor, Natural Neighbor, and two Inverse Distance Weighting methods, and testing their RMSE and CC performance.

main_elec_ori.m: Generates original electric maps.

data_magnetic and data_electric: Data used in the experiments for reconstructing electric and magnetic maps, respectively. They include timestamps and feature values of electromagnetic nodes.

MSM, IDW: Classic interpolation methods used for reconstructing electromagnetic maps, namely Modified Shepard's Method and Inverse Distance Weighting.

CDF: Generates Cumulative Distribution Function plots for relative errors.

box: Generates box plots for absolute errors.

RMSE_CC: Computes Root Mean Square Errors and Correlation Coefficients for the results of four interpolation methods used in reconstructing electromagnetic maps.






