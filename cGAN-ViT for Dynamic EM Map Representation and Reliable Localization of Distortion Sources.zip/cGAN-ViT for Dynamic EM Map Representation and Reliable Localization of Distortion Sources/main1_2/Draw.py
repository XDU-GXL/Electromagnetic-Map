#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
This script reads metrics from the file "time_resolution_experiment.json"
and plots the curves for "cgan_iou", "cgan_dice", and "vit_cls_acc" on the same
coordinate system. The curves are styled according to:
    - cGAN IoU: blue with circle markers and solid line ('o-')
    - cGAN Dice: orange with square markers and dashed line ('s--')
    - ViT Cls Acc: green with triangle markers and dash-dot line ('^-.')

The plot does not display grid lines and is saved as a high-quality SVG file.
"""

import json
import matplotlib.pyplot as plt

def main():
    # Load experiment results from JSON file
    with open("time_resolution_experiment.json", "r") as f:
        data = json.load(f)

    # Sort the keys (time frames T) in numerical order
    T_values = sorted(data.keys(), key=lambda x: int(x))
    T_numeric = [int(t) for t in T_values]

    # Extract metrics for each T value
    cgan_iou   = [data[t]["cgan_iou"]   for t in T_values]
    cgan_dice  = [data[t]["cgan_dice"]  for t in T_values]
    vit_cls_acc = [data[t]["vit_cls_acc"] for t in T_values]

    # Create the plot
    plt.figure(figsize=(8, 6), dpi=600)  # dpi=600 for high image quality

    # Plot each metric with the specified style
    plt.plot(T_numeric, cgan_iou,   'o-', color='blue',   label='cGAN IoU')
    plt.plot(T_numeric, cgan_dice,  's--', color='orange', label='cGAN Dice')
    plt.plot(T_numeric, vit_cls_acc, '^-.', color='green',  label='ViT Cls Acc')

    # Set title and axis labels
    plt.title("Comparison of cGAN and ViT Metrics vs T")
    plt.xlabel("Time Frames (T)")
    plt.ylabel("Metric Value")

    # Add legend and remove grid lines
    plt.legend()
    plt.grid(False)


    # Save the figure as a high-quality SVG file
    plt.savefig("comparison.svg", format="svg", dpi=600, bbox_inches='tight')
    plt.close()

if __name__ == "__main__":
    main()
