#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import random
import math
import numpy as np
import cv2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# TensorFlow
import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras import backend as K
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.losses import BinaryCrossentropy

# sklearn
from sklearn.metrics import confusion_matrix

##############################################################################
# 1. 数据生成（含多种磁场源 + 动态变化）并创建数据集
##############################################################################

def dipole_field_2d_vector(grid_size, x0, y0, moment, inc_deg, dec_deg):
    """
    偶极子磁场模型 (2D)，Bz ~ (M·r)/r^3.
    """
    # inc/dec 转为弧度
    inc = np.radians(inc_deg)
    dec = np.radians(dec_deg)
    # 计算 Mx, My
    Mx = moment * np.cos(inc) * np.cos(dec)
    My = moment * np.cos(inc) * np.sin(dec)

    ix = np.arange(grid_size, dtype=np.float32)
    iy = np.arange(grid_size, dtype=np.float32)
    rx, ry = np.meshgrid(ix, iy, indexing='ij')

    rx = rx - x0
    ry = ry - y0

    r_sq = rx * rx + ry * ry + 1e-12
    r_3 = r_sq ** 1.5
    dotMr = Mx * rx + My * ry
    return dotMr / r_3

def line_current_field_2d_vector(grid_size, x0, y0, current):
    """
    线性电流模型 (2D)，Bz ~ current / r.
    """
    ix = np.arange(grid_size, dtype=np.float32)
    iy = np.arange(grid_size, dtype=np.float32)
    rx, ry = np.meshgrid(ix, iy, indexing='ij')
    rx = rx - x0
    ry = ry - y0
    rr = np.sqrt(rx * rx + ry * ry + 1e-12)
    return current / rr

def quadrupole_field_2d_vector(grid_size, x0, y0, strength):
    """
    四极子模型 (2D)，Bz ~ (2*ry^2 - r^2)/r^3.
    """
    ix = np.arange(grid_size, dtype=np.float32)
    iy = np.arange(grid_size, dtype=np.float32)
    rx, ry = np.meshgrid(ix, iy, indexing='ij')
    rx = rx - x0
    ry = ry - y0
    r_sq = rx * rx + ry * ry + 1e-12
    r_3 = r_sq ** 1.5
    return strength * ((2. * ry * ry - r_sq) / r_3)

def simulate_magnetic_distortion_2d_dynamic(
    grid_size=128,
    max_sources=10,
    background_strength=0.58,
    threshold_ratio=0.04,
    T=5
):
    """
    生成T帧的2D磁场 + (H,W,T)的mask（逐帧阈值）。
    1) 随机生成若干源，并在T个时间步上随某种正弦/余弦函数动态变化;
    2) 根据与背景强度的差值 >= threshold_ratio * background_strength 来得到mask；
    3) 加入随机噪声 (Gaussian / Laplacian / Mixed)，幅度[0.005,0.03].
    返回: field_3d (T,H,W), mask_3d (T,H,W), src_list(源信息).
    """
    # 平坦背景
    frames_field = np.full((T, grid_size, grid_size), background_strength, dtype=np.float32)

    # 随机生成若干源
    n_sources = random.randint(1, max_sources)
    sources_params = []
    for _ in range(n_sources):
        stype = random.randint(0, 2)  # 0=dipole,1=line,2=quad
        x0 = random.uniform(0, grid_size)
        y0 = random.uniform(0, grid_size)

        if stype == 0:  # dipole
            moment_base = random.uniform(0.06, 0.20)
            inc = random.uniform(-30, 30)
            dec = random.uniform(0, 360)
            freq = random.uniform(0.5, 2.0)
            phase = random.uniform(0, 2 * math.pi)
            amps = []
            for t_ in range(T):
                scale = 0.5 + 0.5 * math.sin(freq * (t_ + phase))
                amps.append(scale * moment_base)
            sources_params.append(("dipole", stype, x0, y0, inc, dec, amps))

        elif stype == 1:  # line
            length = random.uniform(5, 20)
            current_base = random.uniform(0.06, 0.20)
            freq = random.uniform(0.5, 2.0)
            phase = random.uniform(0, 2 * math.pi)
            amps = []
            for t_ in range(T):
                scale = 0.5 + 0.5 * math.cos(freq * (t_ + phase))
                amps.append(scale * current_base)
            sources_params.append(("line", stype, x0, y0, length, amps))

        else:  # quad
            strength_base = random.uniform(0.06, 0.20)
            freq = random.uniform(0.5, 2.0)
            phase = random.uniform(0, 2 * math.pi)
            amps = []
            for t_ in range(T):
                scale = 0.5 + 0.5 * math.sin(freq * (t_ + phase))
                amps.append(scale * strength_base)
            sources_params.append(("quad", stype, x0, y0, amps))

    # 叠加各源
    for sp in sources_params:
        if sp[0] == 'dipole':
            x0, y0 = sp[2], sp[3]
            inc, dec = sp[4], sp[5]
            amp_list = sp[6]
            for t_ in range(T):
                field_add = dipole_field_2d_vector(grid_size, x0, y0, amp_list[t_], inc, dec)
                frames_field[t_] += field_add
        elif sp[0] == 'line':
            x0, y0 = sp[2], sp[3]
            amp_list = sp[5]
            for t_ in range(T):
                field_add = line_current_field_2d_vector(grid_size, x0, y0, amp_list[t_])
                frames_field[t_] += field_add
        else:  # quad
            x0, y0 = sp[2], sp[3]
            amp_list = sp[4]
            for t_ in range(T):
                field_add = quadrupole_field_2d_vector(grid_size, x0, y0, amp_list[t_])
                frames_field[t_] += field_add

    # 根据阈值生成mask
    mask_3d = np.zeros_like(frames_field, dtype=np.uint8)
    thr_value = threshold_ratio * background_strength
    for t_ in range(T):
        diff_t = np.abs(frames_field[t_] - background_strength)
        mask_3d[t_] = (diff_t >= thr_value).astype(np.uint8)

    # 添加随机噪声
    noise_amplitude = random.uniform(0.005, 0.03)
    noise_type = random.choice(["gaussian", "laplacian", "mixed"])
    for t_ in range(T):
        if noise_type == "gaussian":
            noise = noise_amplitude * np.random.randn(grid_size, grid_size).astype(np.float32)
        elif noise_type == "laplacian":
            noise = noise_amplitude * np.random.laplace(size=(grid_size, grid_size)).astype(np.float32)
        else:  # "mixed"
            noise = noise_amplitude * (0.5 * np.random.randn(grid_size, grid_size) +
                                       0.5 * np.random.laplace(size=(grid_size, grid_size))).astype(np.float32)
        frames_field[t_] += noise

    # 转成 (H,W,T)
    field_3d = np.transpose(frames_field, (1, 2, 0))
    mask_3d_hw = np.transpose(mask_3d, (1, 2, 0))

    # 简化记录源信息
    src_list = []
    for sp in sources_params:
        if sp[0] == 'dipole':
            avg_m = sum(sp[6]) / len(sp[6])
            src_list.append((sp[0], sp[1], sp[2], sp[3], avg_m, sp[4], sp[5]))
        elif sp[0] == 'line':
            avg_c = sum(sp[5]) / len(sp[5])
            src_list.append((sp[0], sp[1], sp[2], sp[3], sp[4], avg_c))
        else:
            avg_s = sum(sp[4]) / len(sp[4])
            src_list.append((sp[0], sp[1], sp[2], sp[3], avg_s))

    return field_3d, mask_3d_hw, src_list

def create_dataset_dynamic(num_samples=100, grid_size=128, T=5, do_augment=False):
    """
    创建 (N,H,W,T) 的场数据和对应的mask，以及源信息。
    可选择 do_augment=True 进行简单的水平/垂直翻转数据增强。
    """
    X_list, Y_list, info_list = [], [], []
    for _ in range(num_samples):
        f3d_hw, m3d_hw, srcs = simulate_magnetic_distortion_2d_dynamic(
            grid_size=grid_size,
            max_sources=10,
            background_strength=0.58,
            threshold_ratio=0.04,
            T=T
        )
        # 数据增强
        if do_augment:
            # 水平翻转
            if random.random() < 0.5:
                f3d_hw = f3d_hw[:, ::-1, :]
                m3d_hw = m3d_hw[:, ::-1, :]
                new_srcs = []
                for s in srcs:
                    new_y = grid_size - s[3]
                    if s[0] == "dipole":
                        new_src = (s[0], s[1], s[2], new_y, s[4], s[5], s[6])
                    elif s[0] == "line":
                        new_src = (s[0], s[1], s[2], new_y, s[4], s[5])
                    else:
                        new_src = (s[0], s[1], s[2], new_y, s[4])
                    new_srcs.append(new_src)
                srcs = new_srcs
            # 垂直翻转
            if random.random() < 0.5:
                f3d_hw = f3d_hw[::-1, :, :]
                m3d_hw = m3d_hw[::-1, :, :]
                new_srcs = []
                for s in srcs:
                    new_x = grid_size - s[2]
                    if s[0] == "dipole":
                        new_src = (s[0], s[1], new_x, s[3], s[4], s[5], s[6])
                    elif s[0] == "line":
                        new_src = (s[0], s[1], new_x, s[3], s[4], s[5])
                    else:
                        new_src = (s[0], s[1], new_x, s[3], s[4])
                    new_srcs.append(new_src)
                srcs = new_srcs

        X_list.append(f3d_hw)
        Y_list.append(m3d_hw)
        info_list.append(srcs)

    X = np.array(X_list, dtype=np.float32)
    Y = np.array(Y_list, dtype=np.float32)
    return X, Y, info_list

##############################################################################
# 2. 评价指标：IoU, Dice, RMSE等
##############################################################################

def compute_iou(y_true, y_pred):
    """
    计算IoU, 输入 shape=(N,H,W,T) 或 (H,W,T) 皆可。
    """
    y_true_bin = (y_true > 0.5).astype(np.float32)
    y_pred_bin = (y_pred > 0.5).astype(np.float32)
    intersection = np.sum(y_true_bin * y_pred_bin)
    union = np.sum(y_true_bin) + np.sum(y_pred_bin) - intersection
    return (intersection + 1e-6) / (union + 1e-6)

def dice_coef_np(y_true, y_pred, smooth=1e-6):
    """
    计算Dice系数 (非tf版本)。
    """
    y_true_f = (y_true > 0.5).astype(np.float32).flatten()
    y_pred_f = (y_pred > 0.5).astype(np.float32).flatten()
    inter = np.sum(y_true_f * y_pred_f)
    den = np.sum(y_true_f) + np.sum(y_pred_f)
    return (2. * inter + smooth) / (den + smooth)

def rmse(a, b):
    """
    简单 RMSE 计算
    """
    return np.sqrt(np.mean((a - b) ** 2))

##############################################################################
# 3. 构建 cGAN：Attention U-Net + PatchGAN
##############################################################################

def dice_coef(y_true, y_pred, smooth=1e-6):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    inter = K.sum(y_true_f * y_pred_f)
    den = K.sum(y_true_f) + K.sum(y_pred_f)
    return (2. * inter + smooth) / (den + smooth)

def dice_loss(y_true, y_pred):
    return 1.0 - dice_coef(y_true, y_pred)

def combined_bce_dice_loss(y_true, y_pred):
    bce = tf.keras.losses.binary_crossentropy(y_true, y_pred)
    bce = tf.reduce_mean(bce)
    return bce + dice_loss(y_true, y_pred)

def build_attention_unet(input_shape=(128,128,1), out_channels=1):
    """
    注意力U-Net（简化版）
    """
    inp = layers.Input(input_shape)
    c1 = layers.Conv2D(64, 3, padding='same', activation='relu')(inp)
    c1 = layers.Conv2D(64, 3, padding='same', activation='relu')(c1)
    p1 = layers.MaxPooling2D(2)(c1)

    c2 = layers.Conv2D(128, 3, padding='same', activation='relu')(p1)
    c2 = layers.Conv2D(128, 3, padding='same', activation='relu')(c2)
    p2 = layers.MaxPooling2D(2)(c2)

    c3 = layers.Conv2D(256, 3, padding='same', activation='relu')(p2)
    c3 = layers.Conv2D(256, 3, padding='same', activation='relu')(c3)
    p3 = layers.MaxPooling2D(2)(c3)

    c4 = layers.Conv2D(512, 3, padding='same', activation='relu')(p3)
    c4 = layers.Conv2D(512, 3, padding='same', activation='relu')(c4)

    def attention_block(x, g, inter_channels):
        theta_x = layers.Conv2D(inter_channels, 2, strides=2, padding='same')(x)
        phi_g = layers.Conv2D(inter_channels, 1, strides=1, padding='same')(g)
        add_xg = layers.add([theta_x, phi_g])
        act_xg = layers.Activation('relu')(add_xg)
        psi = layers.Conv2D(1, 1, padding='same')(act_xg)
        psi = layers.Activation('sigmoid')(psi)
        psi_up = layers.Conv2DTranspose(1, 2, strides=2, padding='same')(psi)
        return layers.multiply([x, psi_up])

    # decoder
    g3 = layers.Conv2D(256, 1, activation='relu')(c4)
    att3 = attention_block(c3, g3, 256)
    u3 = layers.Conv2DTranspose(256, 2, strides=2, padding='same')(c4)
    u3 = layers.concatenate([u3, att3], axis=-1)
    cc3 = layers.Conv2D(256, 3, padding='same', activation='relu')(u3)
    cc3 = layers.Conv2D(256, 3, padding='same', activation='relu')(cc3)

    g2 = layers.Conv2D(128, 1, activation='relu')(cc3)
    att2 = attention_block(c2, g2, 128)
    u2 = layers.Conv2DTranspose(128, 2, strides=2, padding='same')(cc3)
    u2 = layers.concatenate([u2, att2], axis=-1)
    cc2 = layers.Conv2D(128, 3, padding='same', activation='relu')(u2)
    cc2 = layers.Conv2D(128, 3, padding='same', activation='relu')(cc2)

    g1 = layers.Conv2D(64, 1, activation='relu')(cc2)
    att1 = attention_block(c1, g1, 64)
    u1 = layers.Conv2DTranspose(64, 2, strides=2, padding='same')(cc2)
    u1 = layers.concatenate([u1, att1], axis=-1)
    cc1 = layers.Conv2D(64, 3, padding='same', activation='relu')(u1)
    cc1 = layers.Conv2D(64, 3, padding='same', activation='relu')(cc1)

    outp = layers.Conv2D(out_channels, 1, activation='sigmoid')(cc1)
    return models.Model(inp, outp, name='AttentionUNet')

def build_patchgan_discriminator(input_shape=(128,128,2)):
    inp = layers.Input(input_shape)
    x = layers.Conv2D(64, 4, strides=2, padding='same')(inp)
    x = layers.LeakyReLU(0.2)(x)
    x = layers.Conv2D(128, 4, strides=2, padding='same')(x)
    x = layers.LeakyReLU(0.2)(x)
    x = layers.Conv2D(256, 4, strides=2, padding='same')(x)
    x = layers.LeakyReLU(0.2)(x)
    x = layers.Flatten()(x)
    x = layers.Dense(1)(x)
    return models.Model(inp, x, name='PatchDiscriminator')

class MagneticDistortCGAN(tf.keras.Model):
    def __init__(self, generator, discriminator, lambda_seg=10.0, **kwargs):
        super().__init__(**kwargs)
        self.generator = generator
        self.discriminator = discriminator
        self.lambda_seg = lambda_seg

    def compile(self, g_opt, d_opt, seg_loss_fn, adv_loss_fn):
        super().compile()
        self.g_opt = g_opt
        self.d_opt = d_opt
        self.seg_loss_fn = seg_loss_fn
        self.adv_loss_fn = adv_loss_fn

    def train_step(self, data):
        x, y = data
        with tf.GradientTape() as gtape, tf.GradientTape() as dtape:
            # G forward
            fake_mask = self.generator(x, training=True)
            real_pair = tf.concat([x, y], axis=-1)
            fake_pair = tf.concat([x, fake_mask], axis=-1)

            # D forward
            real_logit = self.discriminator(real_pair, training=True)
            fake_logit = self.discriminator(fake_pair, training=True)

            # G loss
            g_adv = self.adv_loss_fn(tf.ones_like(fake_logit), fake_logit)
            g_seg = self.seg_loss_fn(y, fake_mask) * self.lambda_seg
            g_loss = g_adv + g_seg

            # D loss
            d_real = self.adv_loss_fn(tf.ones_like(real_logit)*0.9, real_logit)  # label smoothing
            d_fake = self.adv_loss_fn(tf.zeros_like(fake_logit), fake_logit)
            d_loss = 0.5 * (d_real + d_fake)

        g_grad = gtape.gradient(g_loss, self.generator.trainable_variables)
        self.g_opt.apply_gradients(zip(g_grad, self.generator.trainable_variables))
        d_grad = dtape.gradient(d_loss, self.discriminator.trainable_variables)
        self.d_opt.apply_gradients(zip(d_grad, self.discriminator.trainable_variables))

        return {"g_loss": g_loss, "g_adv": g_adv, "g_seg": g_seg, "d_loss": d_loss}

##############################################################################
# 4. ViT 模型 (分类 + 位置回归)
##############################################################################

class Patches(layers.Layer):
    def __init__(self, patch_size=16, **kwargs):
        super().__init__(**kwargs)
        self.patch_size = patch_size

    def call(self, images):
        # images: (batch,H,W,C)
        batch_size = tf.shape(images)[0]
        patches = tf.image.extract_patches(
            images=images,
            sizes=[1, self.patch_size, self.patch_size, 1],
            strides=[1, self.patch_size, self.patch_size, 1],
            rates=[1,1,1,1],
            padding='VALID'
        )
        patch_dims = patches.shape[-1]
        patches = tf.reshape(patches, [batch_size, -1, patch_dims])
        return patches

    def get_config(self):
        config = super().get_config()
        config.update({"patch_size": self.patch_size})
        return config

class PatchEncoder(layers.Layer):
    def __init__(self, num_patches, projection_dim, **kwargs):
        super().__init__(**kwargs)
        self.num_patches = num_patches
        self.projection = layers.Dense(units=projection_dim)
        self.position_embedding = layers.Embedding(
            input_dim=num_patches,
            output_dim=projection_dim
        )

    def call(self, patches):
        positions = tf.range(start=0, limit=self.num_patches, delta=1)
        encoded = self.projection(patches) + self.position_embedding(positions)
        return encoded

    def get_config(self):
        config = super().get_config()
        config.update({
            "num_patches": self.num_patches,
            "projection_dim": self.projection.units
        })
        return config

def mlp_transformer_block(x, hidden_units, dropout_rate, out_dim):
    for units in hidden_units:
        x = layers.Dense(units, activation=tf.nn.gelu)(x)
        x = layers.Dropout(dropout_rate)(x)
    x = layers.Dense(out_dim)(x)
    return x

def build_simple_vit(
    input_shape=(96,96,1),
    patch_size=16,
    num_heads=4,
    embed_dim=128,
    ff_dim=256,
    transformer_layers=3,
    num_classes=3
):
    inp = layers.Input(shape=input_shape)
    x = inp

    patches_layer = Patches(patch_size)
    patches = patches_layer(x)
    num_patches = (input_shape[0] // patch_size) * (input_shape[1] // patch_size)

    encoder = PatchEncoder(num_patches, embed_dim)
    x_enc = encoder(patches)

    for _ in range(transformer_layers):
        x1 = layers.LayerNormalization(epsilon=1e-6)(x_enc)
        attention_output = layers.MultiHeadAttention(
            num_heads=num_heads, key_dim=embed_dim, dropout=0.1
        )(x1, x1)
        x2 = layers.Add()([attention_output, x_enc])

        x3 = layers.LayerNormalization(epsilon=1e-6)(x2)
        x3 = mlp_transformer_block(x3, [ff_dim], 0.1, embed_dim)
        x_enc = layers.Add()([x3, x2])

    rep = layers.LayerNormalization(epsilon=1e-6)(x_enc)
    rep = layers.GlobalAveragePooling1D()(rep)
    rep = layers.Dropout(0.5)(rep)

    cls_out = layers.Dense(num_classes, name='patch_cls')(rep)
    pos_out = layers.Dense(2, activation='sigmoid', name='patch_pos')(rep)
    return models.Model(inp, [cls_out, pos_out], name="CustomViT")

##############################################################################
# 5. 可视化函数（与“输出一、输出二、输出三”对应）
##############################################################################

def plot_sources_on_field(ax, field2d, sources, add_colorbar=True):
    """
    在 ax 上绘制 field2d（热力图）并用红叉+白字标记 sources 的位置。
    """
    vmin, vmax = np.percentile(field2d, [5, 95])
    img_handle = ax.imshow(field2d, cmap='turbo', vmin=vmin, vmax=vmax)
    for s in sources:
        tname = s[0]
        x0 = s[2]
        y0 = s[3]
        ax.plot(y0, x0, 'rx', ms=5, mew=1.5)
        ax.text(y0 + 2, x0 + 2, f"{tname}\n({x0:.1f},{y0:.1f})",
                color='white', fontsize=6,
                bbox=dict(facecolor='black', alpha=0.3, pad=1))
    ax.axis('off')
    return img_handle

def visualize_output_1(X, Y, Sinfo, out_dir="outputs/output_1", count=10):
    """
    输出一：原始数据(标注源信息) + GT mask
    """
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)
    indices = np.random.choice(len(X), size=min(count, len(X)), replace=False)
    for idx_num, i in enumerate(indices):
        field_hw_t = X[i]  # (H,W,T)
        mask_hw_t = Y[i]   # (H,W,T)
        sources = Sinfo[i]
        H, W, T = field_hw_t.shape

        plt.figure(figsize=(3*T, 6))
        for t_ in range(T):
            # 上面一行：原始数据
            plt.subplot(2, T, t_+1)
            fm_ = field_hw_t[..., t_]
            im_handle = plot_sources_on_field(plt.gca(), fm_, sources)
            snr = np.mean(fm_) / (np.std(fm_)+1e-6)
            plt.text(5, 15, f"SNR: {snr:.2f}", color="yellow", fontsize=6,
                     bbox=dict(facecolor="black", alpha=0.3, pad=1))
            plt.title(f"Field t={t_}")
            plt.colorbar(im_handle, ax=plt.gca(), fraction=0.046, pad=0.04)

            # 下面一行：GT mask
            plt.subplot(2, T, T+t_+1)
            plt.imshow(mask_hw_t[..., t_], cmap='gray', vmin=0, vmax=1)
            plt.title(f"Mask t={t_}")
            plt.axis('off')

        plt.suptitle(f"Sample {i} (Output_1)")
        plt.tight_layout()
        save_path = os.path.join(out_dir, f"sample_{idx_num}.svg")
        plt.savefig(save_path, format='svg', dpi=600, bbox_inches='tight')
        plt.close()

def visualize_output_2(X, Y, Pred, Sinfo, out_dir="outputs/output_2", count=10):
    """
    输出二：原始数据 + GT + 预测Mask(含Dice)
    """
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    indices = np.random.choice(len(X), size=min(count, len(X)), replace=False)
    for idx_num, i in enumerate(indices):
        field_hw_t = X[i]   # (H,W,T)
        mask_hw_t  = Y[i]   # (H,W,T)
        pred_hw_t  = Pred[i]
        sources    = Sinfo[i]
        H, W, T = field_hw_t.shape

        # 计算全帧Dice
        dice_val = dice_coef_np(mask_hw_t, pred_hw_t)

        plt.figure(figsize=(3*T, 9))
        for t_ in range(T):
            # 第一行：原始数据
            plt.subplot(3, T, t_+1)
            fm_ = field_hw_t[..., t_]
            im_handle = plot_sources_on_field(plt.gca(), fm_, sources)
            plt.title(f"Field t={t_}")
            plt.colorbar(im_handle, ax=plt.gca(), fraction=0.046, pad=0.04)

            # 第二行：GT mask
            plt.subplot(3, T, T+t_+1)
            plt.imshow(mask_hw_t[..., t_], cmap='gray', vmin=0, vmax=1)
            plt.title(f"GT Mask t={t_}")
            plt.axis('off')

            # 第三行：预测Mask
            plt.subplot(3, T, 2*T+t_+1)
            plt.imshow(pred_hw_t[..., t_], cmap='gray', vmin=0, vmax=1)
            plt.title(f"Pred t={t_}")
            plt.axis('off')

        plt.suptitle(f"Sample {i} (Output_2) - Dice={dice_val:.3f}")
        plt.tight_layout()
        save_path = os.path.join(out_dir, f"sample_{idx_num}.svg")
        plt.savefig(save_path, format='svg', dpi=600, bbox_inches='tight')
        plt.close()

def visualize_output_3(X, Y, Sinfo, vit_model, out_dir="outputs/output_3", count=10):
    """
    输出三：分两行T列
    - 第一行显示原始数据(含真源标记)
    - 第二行显示ViT预测(分类+位置回归)
    """
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    type_map = {0: "dipole", 1: "line", 2: "quad"}

    indices = np.random.choice(len(X), size=min(count, len(X)), replace=False)
    for idx_num, sample_idx in enumerate(indices):
        field_hw_t = X[sample_idx]  # (H,W,T)
        mask_hw_t  = Y[sample_idx]  # (H,W,T)
        sources    = Sinfo[sample_idx]
        H, W, T = field_hw_t.shape

        plt.figure(figsize=(3*T, 6))
        for t_ in range(T):
            # 第一行：原始数据
            plt.subplot(2, T, t_+1)
            fm_ = field_hw_t[..., t_]
            im_handle = plot_sources_on_field(plt.gca(), fm_, sources)
            plt.title(f"Field t={t_}")
            plt.colorbar(im_handle, ax=plt.gca(), fraction=0.046, pad=0.04)

            # 第二行：ViT分类+位置回归结果
            plt.subplot(2, T, T + t_ + 1)
            plt.imshow(fm_, cmap='turbo',
                       vmin=np.percentile(fm_, 5),
                       vmax=np.percentile(fm_, 95))
            plt.title(f"Cls+Reg t={t_}")
            plt.axis('off')
            plt.colorbar(ax=plt.gca(), fraction=0.046, pad=0.04)

            # 在 mask 上找连通域，并用 ViT 做预测
            mask_t = mask_hw_t[..., t_].astype(np.uint8)
            num_l, labels, stats, centroids = cv2.connectedComponentsWithStats(mask_t, connectivity=8)
            for lb in range(1, num_l):
                x2 = stats[lb, cv2.CC_STAT_LEFT]
                y2 = stats[lb, cv2.CC_STAT_TOP]
                w2 = stats[lb, cv2.CC_STAT_WIDTH]
                h2 = stats[lb, cv2.CC_STAT_HEIGHT]
                if w2 < 2 or h2 < 2:
                    continue
                sub_img = field_hw_t[y2:y2+h2, x2:x2+w2, :]
                sub_img_res = np.zeros((96, 96, T), dtype=np.float32)
                for chan in range(T):
                    tmp = cv2.resize(sub_img[..., chan], (96, 96))
                    mm, ss = tmp.mean(), tmp.std() + 1e-6
                    tmp = (tmp - mm) / ss
                    sub_img_res[..., chan] = tmp
                sub_img_res = np.expand_dims(sub_img_res, axis=0)

                pred_cls_logits, pred_pos = vit_model.predict(sub_img_res, verbose=0)
                pred_cls_id = np.argmax(pred_cls_logits[0])
                pred_cls_str = type_map.get(pred_cls_id, "Unknown")

                px, py = pred_pos[0]
                pred_x0 = y2 + px*h2  # 行坐标
                pred_y0 = x2 + py*w2  # 列坐标

                plt.plot(pred_y0, pred_x0, 'rx', ms=5, mew=1.5)
                plt.text(pred_y0 + 2, pred_x0 + 2,
                         f"{pred_cls_str}\n({pred_x0:.1f},{pred_y0:.1f})",
                         color='white', fontsize=6,
                         bbox=dict(facecolor='black', alpha=0.3, pad=1))

        plt.suptitle(f"Sample {sample_idx} (Output_3)")
        plt.tight_layout()
        out_file = os.path.join(out_dir, f"sample_{idx_num}.svg")
        plt.savefig(out_file, format='svg', dpi=600, bbox_inches='tight')
        plt.close()

##############################################################################
# 6. 实验主流程：测试不同 T（时间帧数），并记录结果到 JSON
##############################################################################

def run_experiment_for_time_frames(
    T_values=[1,3,5],
    num_samples=1000,
    grid_size=128,
    out_json="time_resolution_experiment.json",
    do_visualize=True
):
    """
    对不同的帧数 T 进行测试并保存结果.
    1) 生成数据, 训练并评估 cGAN (IoU, Dice)
    2) 训练并评估 ViT (分类准确度, 定位RMSE)
    3) 可视化 output_1,2,3 (可选)
    4) 保存结果到 JSON
    """

    results_dict = {}

    for T in T_values:
        print(f"\n[EXPERIMENT] T={T} -----------------------")

        # 1) 生成数据
        print(f" -> Generating data with T={T} ...")
        X_all, Y_all, Src_all = create_dataset_dynamic(
            num_samples=num_samples,
            grid_size=grid_size,
            T=T,
            do_augment=True
        )
        idx_split = int(0.7 * num_samples)
        X_train, Y_train = X_all[:idx_split], Y_all[:idx_split]
        X_test,  Y_test  = X_all[idx_split:], Y_all[idx_split:]
        Sinfo_tr, Sinfo_ts = Src_all[:idx_split], Src_all[idx_split:]

        # 2) cGAN 训练
        print(f" -> Building & training cGAN (T={T}) ...")
        generator = build_attention_unet(
            input_shape=(grid_size, grid_size, T),
            out_channels=T
        )
        discriminator = build_patchgan_discriminator(
            (grid_size, grid_size, 2*T)
        )
        cgan = MagneticDistortCGAN(generator, discriminator, lambda_seg=12.0)

        adv_bce = BinaryCrossentropy(from_logits=True)
        cgan.compile(
            g_opt=Adam(1e-4, beta_1=0.5),
            d_opt=Adam(1e-4, beta_1=0.5),
            seg_loss_fn=combined_bce_dice_loss,
            adv_loss_fn=adv_bce
        )
        # 为了节省时间，这里将 epochs 设得较小，如需更好效果可增大
        cgan.fit(X_train, Y_train, batch_size=4, epochs=150, verbose=0)

        # cGAN 测试集评估
        preds_test = generator.predict(X_test)
        iou_val = compute_iou(Y_test, preds_test)
        dice_val = dice_coef_np(Y_test, preds_test)
        print(f"    cGAN test IoU={iou_val:.4f}, Dice={dice_val:.4f}")

        # 3) ViT: 对训练集所有连通域进行分类+位置监督
        patch_imgs, patch_cls, patch_pos = [], [], []
        for i in range(len(X_train)):
            union_mask = np.max(Y_train[i], axis=-1).astype(np.uint8)
            num_l, _, stats, centroids = cv2.connectedComponentsWithStats(union_mask, connectivity=8)

            # 每个源与最近的连通域绑定
            for src in Sinfo_tr[i]:
                stype_id = src[1]  # 0/1/2
                x0, y0 = src[2], src[3]
                best_lb, best_d = None, 1e9
                for lb in range(1, num_l):
                    cx, cy = centroids[lb]  # (cx, cy) = (x坐标, y坐标)
                    dd = (cy - x0)**2 + (cx - y0)**2
                    if dd < best_d:
                        best_d = dd
                        best_lb = lb
                if best_lb is None:
                    continue
                x2 = stats[best_lb, cv2.CC_STAT_LEFT]
                y2 = stats[best_lb, cv2.CC_STAT_TOP]
                w2 = stats[best_lb, cv2.CC_STAT_WIDTH]
                h2 = stats[best_lb, cv2.CC_STAT_HEIGHT]
                if w2 < 2 or h2 < 2:
                    continue

                sub_img = X_train[i, y2:y2+h2, x2:x2+w2, :]
                sub_res = np.zeros((96, 96, T), dtype=np.float32)
                for t_ in range(T):
                    tmp = cv2.resize(sub_img[..., t_], (96, 96))
                    mm, ss = tmp.mean(), tmp.std() + 1e-6
                    tmp = (tmp - mm) / ss
                    sub_res[..., t_] = tmp

                # 相对坐标 (行偏移,列偏移)
                roff = (x0 - y2) / (h2 + 1e-6)
                coff = (y0 - x2) / (w2 + 1e-6)

                patch_imgs.append(sub_res)
                patch_cls.append(stype_id)
                patch_pos.append([roff, coff])

        patch_imgs = np.array(patch_imgs, dtype=np.float32)
        patch_cls = np.array(patch_cls, dtype=np.int32)
        patch_pos = np.array(patch_pos, dtype=np.float32)

        # ViT 模型
        vit = build_simple_vit(
            input_shape=(96,96,T),
            patch_size=16,
            num_heads=8,
            embed_dim=256,
            ff_dim=512,
            transformer_layers=4,
            num_classes=3
        )
        vit.compile(
            optimizer=Adam(1e-4),
            loss={
                "patch_cls": tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
                "patch_pos": tf.keras.losses.MeanSquaredError()
            },
            loss_weights={"patch_cls": 2.0, "patch_pos": 0.05},
            metrics={"patch_cls": "accuracy"}
        )

        # 训练集/验证集拆分
        idxs = np.arange(len(patch_imgs))
        np.random.shuffle(idxs)
        spn = int(0.7 * len(idxs))  # 80%训练，20%验证
        id_tr, id_vl = idxs[:spn], idxs[spn:]

        vit.fit(
            patch_imgs[id_tr],
            {"patch_cls": patch_cls[id_tr], "patch_pos": patch_pos[id_tr]},
            validation_data=(
                patch_imgs[id_vl],
                {"patch_cls": patch_cls[id_vl], "patch_pos": patch_pos[id_vl]}
            ),
            epochs=50,
            batch_size=8,
            verbose=0
        )

        # 在测试集（连通域级别）评估 ViT
        # 注意，这里为了简单，只评估 X_test 里的连通域 + 真源做匹配
        # 真实实验中可看需求是否需要更复杂的匹配逻辑
        test_cls_true, test_cls_pred = [], []
        test_pos_true, test_pos_pred = [], []

        for i in range(len(X_test)):
            union_mask = np.max(Y_test[i], axis=-1).astype(np.uint8)
            num_l, _, stats, centroids = cv2.connectedComponentsWithStats(union_mask, connectivity=8)

            # 每个源
            for src in Sinfo_ts[i]:
                stype_id = src[1]
                x0, y0 = src[2], src[3]

                best_lb, best_d = None, 1e9
                for lb in range(1, num_l):
                    cx, cy = centroids[lb]
                    dd = (cy - x0)**2 + (cx - y0)**2
                    if dd < best_d:
                        best_d = dd
                        best_lb = lb
                if best_lb is None:
                    continue
                x2 = stats[best_lb, cv2.CC_STAT_LEFT]
                y2 = stats[best_lb, cv2.CC_STAT_TOP]
                w2 = stats[best_lb, cv2.CC_STAT_WIDTH]
                h2 = stats[best_lb, cv2.CC_STAT_HEIGHT]
                if w2 < 2 or h2 < 2:
                    continue

                sub_img = X_test[i, y2:y2+h2, x2:x2+w2, :]
                sub_res = np.zeros((96, 96, T), dtype=np.float32)
                for t_ in range(T):
                    tmp = cv2.resize(sub_img[..., t_], (96, 96))
                    mm, ss = tmp.mean(), tmp.std() + 1e-6
                    tmp = (tmp - mm) / ss
                    sub_res[..., t_] = tmp
                sub_res = np.expand_dims(sub_res, axis=0)

                # 真值
                test_cls_true.append(stype_id)
                # 计算相对真值
                roff_true = (x0 - y2) / (h2 + 1e-6)
                coff_true = (y0 - x2) / (w2 + 1e-6)
                test_pos_true.append([roff_true, coff_true])

                # 预测
                pred_cls_logits, pred_pos = vit.predict(sub_res, verbose=0)
                pred_cls = np.argmax(pred_cls_logits[0])
                px, py = pred_pos[0]

                test_cls_pred.append(pred_cls)
                test_pos_pred.append([px, py])

        test_cls_true = np.array(test_cls_true)
        test_cls_pred = np.array(test_cls_pred)
        test_pos_true = np.array(test_pos_true)
        test_pos_pred = np.array(test_pos_pred)
        cls_acc = np.mean(test_cls_true == test_cls_pred) if len(test_cls_true) > 0 else 0.0
        pos_rmse_val = rmse(test_pos_true, test_pos_pred) if len(test_pos_true) > 0 else 0.0
        print(f"    ViT test ClsAcc={cls_acc:.4f}, PosRMSE={pos_rmse_val:.4f}")

        # 存入结果字典
        results_dict[T] = {
            "cgan_iou": float(iou_val),
            "cgan_dice": float(dice_val),
            "vit_cls_acc": float(cls_acc),
            "vit_pos_rmse": float(pos_rmse_val)
        }

        # 可选：做一些可视化
        if do_visualize:
            # 这里只可视化测试集的一小部分
            # output_1
            visualize_output_1(X_test, Y_test, Sinfo_ts, out_dir=f"outputs/T{T}_output_1", count=5)
            # output_2
            visualize_output_2(X_test, Y_test, preds_test, Sinfo_ts, out_dir=f"outputs/T{T}_output_2", count=5)
            # output_3
            visualize_output_3(X_test, Y_test, Sinfo_ts, vit, out_dir=f"outputs/T{T}_output_3", count=5)

    # 保存 JSON
    with open(out_json, "w") as f:
        json.dump(results_dict, f, indent=2)
    print(f"\n[INFO] Done. Results saved to {out_json}")

##############################################################################
# 7. 主入口
##############################################################################

if __name__ == "__main__":
    # 指定要测试的 T 列表，可以根据需求改动
    T_list = [1, 3, 5, 7, 9]
    run_experiment_for_time_frames(
        T_values=T_list,
        num_samples=1000,    # 这里可酌情增减，为了示例速度设置较小
        grid_size=128,
        out_json="time_resolution_experiment.json",
        do_visualize=True
    )
