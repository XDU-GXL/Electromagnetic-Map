#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import math
import random
import json
import numpy as np
import cv2
import pandas as pd

# 若环境可用GPU版本cupy，请保留这些；否则可改为只使用numpy
import cupy as cp
import cupyx.scipy.ndimage as ndi

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.losses import BinaryCrossentropy
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras import backend as K

# 若需要混淆矩阵等，可以用sklearn
from sklearn.metrics import confusion_matrix


###############################################################################
# 1. 基础工具函数
###############################################################################
def compute_iou(y_true, y_pred):
    """
    按全局像素计算 IoU。
    """
    y_true_bin = (y_true > 0.5).astype(np.float32)
    y_pred_bin = (y_pred > 0.5).astype(np.float32)
    intersection = np.sum(y_true_bin * y_pred_bin)
    union = np.sum(y_true_bin) + np.sum(y_pred_bin) - intersection
    return (intersection + 1e-6) / (union + 1e-6)

def compute_dice(y_true, y_pred):
    """
    按全局像素计算 Dice。
    """
    y_true_bin = (y_true > 0.5).astype(np.float32)
    y_pred_bin = (y_pred > 0.5).astype(np.float32)
    inter = np.sum(y_true_bin * y_pred_bin)
    den   = np.sum(y_true_bin) + np.sum(y_pred_bin)
    dice_val = (2. * inter + 1e-6)/(den + 1e-6)
    return dice_val


###############################################################################
# 2. 2D磁场模拟函数（Vector化）
###############################################################################
def dipole_field_2d_vector(grid_size, x0, y0, moment, inc_deg, dec_deg):
    """
    使用 cupy 向量化计算偶极子场: Bz ~ (M·r)/r^3
    """
    inc = cp.radians(inc_deg)
    dec = cp.radians(dec_deg)
    # 计算 Mx, My
    Mx = moment * cp.cos(inc) * cp.cos(dec)
    My = moment * cp.cos(inc) * cp.sin(dec)

    ix = cp.arange(grid_size, dtype=cp.float32)
    iy = cp.arange(grid_size, dtype=cp.float32)
    rx, ry = cp.meshgrid(ix, iy, indexing='ij')  # shape=(grid_size,grid_size)

    rx = rx - x0
    ry = ry - y0

    r_sq = rx*rx + ry*ry + 1e-12
    r_3  = r_sq**1.5
    dotMr= Mx*rx + My*ry
    return dotMr / r_3  # shape=(grid_size,grid_size)

def line_current_field_2d_vector(grid_size, x0, y0, current):
    """
    使用 cupy 向量化计算线电流场 (简化): Bz ~ current / r
    """
    ix = cp.arange(grid_size, dtype=cp.float32)
    iy = cp.arange(grid_size, dtype=cp.float32)
    rx, ry = cp.meshgrid(ix, iy, indexing='ij')
    rx = rx - x0
    ry = ry - y0
    rr = cp.sqrt(rx*rx + ry*ry + 1e-12)
    return current / rr

def quadrupole_field_2d_vector(grid_size, x0, y0, strength):
    """
    使用 cupy 向量化计算四极子场（简化模型）: Bz ~ (2*ry^2 - r^2)/r^3
    """
    ix = cp.arange(grid_size, dtype=cp.float32)
    iy = cp.arange(grid_size, dtype=cp.float32)
    rx, ry = cp.meshgrid(ix, iy, indexing='ij')
    rx = rx - x0
    ry = ry - y0
    r_sq= rx*rx + ry*ry + 1e-12
    r_3 = r_sq**1.5
    return strength*((2.*ry*ry - r_sq)/r_3)


###############################################################################
# 3. 动态2D磁场 + Mask生成函数 (可指定噪声类型与幅度)
###############################################################################
def simulate_magnetic_distortion_2d_dynamic(
    grid_size=128,
    max_sources=10,
    background_strength=0.58,
    threshold_ratio=0.04,
    T=5,
    noise_type=None,
    noise_amplitude=None
):
    """
    生成 T 帧的2D磁场 + Mask(逐帧阈值)。可选指定噪声类型和幅度。
      - noise_type: "gaussian" / "laplacian" / "mixed" / None(则随机)
      - noise_amplitude: float / None(则随机)

    返回:
      field_3d: shape (T,H,W)
      mask_3d:  shape (T,H,W)
      src_list: 源信息列表
    """
    # 背景平坦
    base_bg = background_strength * cp.ones((grid_size, grid_size), dtype=cp.float32)

    # 随机生成若干源
    n_sources= random.randint(1, max_sources)
    sources_params = []
    for _ in range(n_sources):
        stype = random.randint(0,2)  # 0=dipole,1=line,2=quad
        x0 = random.uniform(0, grid_size)
        y0 = random.uniform(0, grid_size)

        if stype == 0:  # dipole
            moment_base = random.uniform(0.06, 0.20)
            inc = random.uniform(-30, 30)
            dec = random.uniform(0, 360)
            freq = random.uniform(0.5, 2.0)
            phase= random.uniform(0, 2*math.pi)
            amps = []
            for t_ in range(T):
                scale = 0.5 + 0.5*math.sin(freq*(t_ + phase))
                amps.append(scale * moment_base)
            sources_params.append(("dipole", stype, x0, y0, inc, dec, amps))

        elif stype == 1:  # line
            length = random.uniform(5, 20)
            current_base= random.uniform(0.06, 0.20)
            freq = random.uniform(0.5, 2.0)
            phase= random.uniform(0, 2*math.pi)
            amps = []
            for t_ in range(T):
                scale = 0.5 + 0.5*math.cos(freq*(t_ + phase))
                amps.append(scale * current_base)
            sources_params.append(("line", stype, x0, y0, length, amps))

        else:  # quad
            strength_base = random.uniform(0.06, 0.20)
            freq = random.uniform(0.5, 2.0)
            phase= random.uniform(0, 2*math.pi)
            amps = []
            for t_ in range(T):
                scale = 0.5 + 0.5*math.sin(freq*(t_ + phase))
                amps.append(scale * strength_base)
            sources_params.append(("quad", stype, x0, y0, amps))

    # 初始化 T 帧的场
    frames_field = cp.tile(base_bg[None, ...], (T, 1, 1))  # shape=(T,H,W)

    # 累加各源对每帧的贡献
    for sp in sources_params:
        if sp[0] == 'dipole':
            x0   = sp[2]
            y0   = sp[3]
            inc  = sp[4]
            dec  = sp[5]
            amp_list = sp[6]
            for t_ in range(T):
                field_add = dipole_field_2d_vector(grid_size, x0, y0, amp_list[t_], inc, dec)
                frames_field[t_] += field_add
        elif sp[0] == 'line':
            x0   = sp[2]
            y0   = sp[3]
            amp_list = sp[5]
            for t_ in range(T):
                field_add = line_current_field_2d_vector(grid_size, x0, y0, amp_list[t_])
                frames_field[t_] += field_add
        else:
            x0   = sp[2]
            y0   = sp[3]
            amp_list = sp[4]
            for t_ in range(T):
                field_add = quadrupole_field_2d_vector(grid_size, x0, y0, amp_list[t_])
                frames_field[t_] += field_add

    # 生成无噪声情况下的mask
    mask_3d_cp  = cp.zeros_like(frames_field, dtype=cp.uint8)
    thr_value   = threshold_ratio * background_strength
    for t_ in range(T):
        diff_t = cp.abs(frames_field[t_] - background_strength)
        mask_3d_cp[t_] = (diff_t >= thr_value).astype(cp.uint8)

    # 如果未指定 noise_type 或 noise_amplitude，则在原逻辑中随机
    if noise_type is None:
        noise_type = random.choice(["gaussian", "laplacian", "mixed"])
    if noise_amplitude is None:
        noise_amplitude = random.uniform(0.005, 0.03)

    # 在每帧上添加对应类型和幅度的噪声
    for t_ in range(T):
        if noise_type == "gaussian":
            noise_cp = noise_amplitude * cp.random.randn(grid_size, grid_size).astype(cp.float32)
        elif noise_type == "laplacian":
            noise_cp = noise_amplitude * cp.random.laplace(size=(grid_size, grid_size)).astype(cp.float32)
        else:  # "mixed"
            noise_cp = noise_amplitude * (
                0.5 * cp.random.randn(grid_size, grid_size).astype(cp.float32) +
                0.5 * cp.random.laplace(size=(grid_size, grid_size)).astype(cp.float32)
            )
        frames_field[t_] += noise_cp

    # 转回CPU
    field_3d = frames_field.get().astype(np.float32)  # (T,H,W)
    mask_3d  = mask_3d_cp.get().astype(np.uint8)      # (T,H,W)

    # 简化记录：仅存平均幅度等
    src_list = []
    for sp in sources_params:
        if sp[0] == 'dipole':
            avg_m = sum(sp[6]) / len(sp[6])
            src_list.append((sp[0], sp[1], sp[2], sp[3], avg_m, sp[4], sp[5]))
        elif sp[0] == 'line':
            avg_c = sum(sp[5]) / len(sp[5])
            src_list.append((sp[0], sp[1], sp[2], sp[3], sp[4], avg_c))
        else:
            avg_s = sum(sp[4]) / len(sp[4])
            src_list.append((sp[0], sp[1], sp[2], sp[3], avg_s))

    return field_3d, mask_3d, src_list


def create_dataset_dynamic(num_samples=100, grid_size=128, T=5,
                          noise_type=None,
                          noise_amplitude=None,
                          do_augment=False):
    """
    生成动态数据 (N,H,W,T) 及其 mask (N,H,W,T)。
    可以额外指定噪声类型与幅度来进行一致性测试。
    """
    X_list, Y_list, info_list = [], [], []
    for _ in range(num_samples):
        f3d, m3d, srcs = simulate_magnetic_distortion_2d_dynamic(
            grid_size=grid_size,
            max_sources=10,
            background_strength=0.58,
            threshold_ratio=0.04,
            T=T,
            noise_type=noise_type,
            noise_amplitude=noise_amplitude
        )
        # (T,H,W) -> (H,W,T)
        f3d_hw = np.transpose(f3d, (1,2,0))  # (H,W,T)
        m3d_hw = np.transpose(m3d, (1,2,0))  # (H,W,T)

        # 数据增强（随机翻转）
        if do_augment:
            # 50%水平翻转
            if random.random() < 0.5:
                f3d_hw = f3d_hw[:, ::-1, :]
                m3d_hw = m3d_hw[:, ::-1, :]
                new_srcs = []
                for s in srcs:
                    # s=(type, stype, x0, y0, ...)
                    # 其中 x0=行, y0=列
                    new_y = grid_size - s[3]  # 反转列
                    if s[0] == "dipole":
                        new_src = (s[0], s[1], s[2], new_y, s[4], s[5], s[6])
                    elif s[0] == "line":
                        new_src = (s[0], s[1], s[2], new_y, s[4], s[5])
                    else:
                        new_src = (s[0], s[1], s[2], new_y, s[4])
                    new_srcs.append(new_src)
                srcs = new_srcs

            # 50%垂直翻转
            if random.random() < 0.5:
                f3d_hw = f3d_hw[::-1, :, :]
                m3d_hw = m3d_hw[::-1, :, :]
                new_srcs = []
                for s in srcs:
                    new_x = grid_size - s[2]  # 反转行
                    if s[0] == "dipole":
                        new_src = (s[0], s[1], new_x, s[3], s[4], s[5], s[6])
                    elif s[0] == "line":
                        new_src = (s[0], s[1], new_x, s[3], s[4], s[5])
                    else:
                        new_src = (s[0], s[1], new_x, s[3], s[4])
                    new_srcs.append(new_src)
                srcs = new_srcs

        X_list.append(f3d_hw)
        Y_list.append(m3d_hw)
        info_list.append(srcs)

    X = np.array(X_list, dtype=np.float32)  # (N,H,W,T)
    Y = np.array(Y_list, dtype=np.float32)  # (N,H,W,T)
    return X, Y, info_list


###############################################################################
# 4. cGAN (Attention U-Net + PatchGAN) 定义
###############################################################################
def dice_coef(y_true, y_pred, smooth=1e-6):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    inter = K.sum(y_true_f * y_pred_f)
    den   = K.sum(y_true_f) + K.sum(y_pred_f)
    return (2.*inter+smooth)/(den+smooth)

def dice_loss(y_true, y_pred):
    return 1.0 - dice_coef(y_true, y_pred)

def combined_bce_dice_loss(y_true, y_pred):
    bce = tf.keras.losses.binary_crossentropy(y_true, y_pred)
    bce = tf.reduce_mean(bce)
    return bce + dice_loss(y_true, y_pred)

def focal_bce_loss(y_true, y_pred, gamma=2.0):
    """
    可选的 Focal Loss(基于binary cross-entropy)
    """
    bce = tf.keras.losses.binary_crossentropy(y_true, y_pred)
    pt  = tf.exp(-bce)
    focal = (1-pt)**gamma * bce
    return tf.reduce_mean(focal)

def build_attention_unet(input_shape=(128,128,1), out_channels=1):
    """
    简化版的 Attention U-Net
    """
    inp = layers.Input(input_shape)
    c1 = layers.Conv2D(64, 3, padding='same', activation='relu')(inp)
    c1 = layers.Conv2D(64, 3, padding='same', activation='relu')(c1)
    p1 = layers.MaxPooling2D(2)(c1)

    c2 = layers.Conv2D(128, 3, padding='same', activation='relu')(p1)
    c2 = layers.Conv2D(128, 3, padding='same', activation='relu')(c2)
    p2 = layers.MaxPooling2D(2)(c2)

    c3 = layers.Conv2D(256, 3, padding='same', activation='relu')(p2)
    c3 = layers.Conv2D(256, 3, padding='same', activation='relu')(c3)
    p3 = layers.MaxPooling2D(2)(c3)

    c4 = layers.Conv2D(512, 3, padding='same', activation='relu')(p3)
    c4 = layers.Conv2D(512, 3, padding='same', activation='relu')(c4)

    def attention_block(x, g, inter_channels):
        theta_x = layers.Conv2D(inter_channels, 2, strides=2, padding='same')(x)
        phi_g   = layers.Conv2D(inter_channels, 1, strides=1, padding='same')(g)
        add_xg  = layers.add([theta_x, phi_g])
        act_xg  = layers.Activation('relu')(add_xg)
        psi     = layers.Conv2D(1, 1, padding='same')(act_xg)
        psi     = layers.Activation('sigmoid')(psi)
        psi_up  = layers.Conv2DTranspose(1, 2, strides=2, padding='same')(psi)
        return layers.multiply([x, psi_up])

    g3   = layers.Conv2D(256, 1, activation='relu')(c4)
    att3 = attention_block(c3, g3, 256)
    u3   = layers.Conv2DTranspose(256, 2, strides=2, padding='same')(c4)
    u3   = layers.concatenate([u3, att3], axis=-1)
    cc3  = layers.Conv2D(256, 3, padding='same', activation='relu')(u3)
    cc3  = layers.Conv2D(256, 3, padding='same', activation='relu')(cc3)

    g2   = layers.Conv2D(128, 1, activation='relu')(cc3)
    att2 = attention_block(c2, g2, 128)
    u2   = layers.Conv2DTranspose(128, 2, strides=2, padding='same')(cc3)
    u2   = layers.concatenate([u2, att2], axis=-1)
    cc2  = layers.Conv2D(128, 3, padding='same', activation='relu')(u2)
    cc2  = layers.Conv2D(128, 3, padding='same', activation='relu')(cc2)

    g1   = layers.Conv2D(64, 1, activation='relu')(cc2)
    att1 = attention_block(c1, g1, 64)
    u1   = layers.Conv2DTranspose(64, 2, strides=2, padding='same')(cc2)
    u1   = layers.concatenate([u1, att1], axis=-1)
    cc1  = layers.Conv2D(64, 3, padding='same', activation='relu')(u1)
    cc1  = layers.Conv2D(64, 3, padding='same', activation='relu')(cc1)

    outp = layers.Conv2D(out_channels, 1, activation='sigmoid')(cc1)
    return models.Model(inp, outp, name='AttentionUNet')


def build_patchgan_discriminator(input_shape=(128,128,2)):
    inp = layers.Input(input_shape)
    x   = layers.Conv2D(64, 4, strides=2, padding='same')(inp)
    x   = layers.LeakyReLU(0.2)(x)
    x   = layers.Conv2D(128, 4, strides=2, padding='same')(x)
    x   = layers.LeakyReLU(0.2)(x)
    x   = layers.Conv2D(256, 4, strides=2, padding='same')(x)
    x   = layers.LeakyReLU(0.2)(x)
    x   = layers.Flatten()(x)
    x   = layers.Dense(1)(x)
    return models.Model(inp, x, name='PatchDiscriminator')


class MagneticDistortCGAN(tf.keras.Model):
    def __init__(self, generator, discriminator, lambda_seg=10.0, **kwargs):
        super().__init__(**kwargs)
        self.generator     = generator
        self.discriminator = discriminator
        self.lambda_seg    = lambda_seg

    def compile(self, g_opt, d_opt, seg_loss_fn, adv_loss_fn):
        super().compile()
        self.g_opt       = g_opt
        self.d_opt       = d_opt
        self.seg_loss_fn = seg_loss_fn
        self.adv_loss_fn = adv_loss_fn

    def train_step(self, data):
        x, y = data
        with tf.GradientTape() as gtape, tf.GradientTape() as dtape:
            fake_mask = self.generator(x, training=True)
            real_pair = tf.concat([x, y], axis=-1)
            fake_pair = tf.concat([x, fake_mask], axis=-1)

            real_logit = self.discriminator(real_pair, training=True)
            fake_logit = self.discriminator(fake_pair, training=True)

            g_adv = self.adv_loss_fn(tf.ones_like(fake_logit), fake_logit)
            g_seg = self.seg_loss_fn(y, fake_mask) * self.lambda_seg
            g_loss = g_adv + g_seg

            # label smoothing for real label *0.9
            d_real = self.adv_loss_fn(tf.ones_like(real_logit) * 0.9, real_logit)
            d_fake = self.adv_loss_fn(tf.zeros_like(fake_logit), fake_logit)
            d_loss = 0.5 * (d_real + d_fake)

        g_grad = gtape.gradient(g_loss, self.generator.trainable_variables)
        self.g_opt.apply_gradients(zip(g_grad, self.generator.trainable_variables))
        d_grad = dtape.gradient(d_loss, self.discriminator.trainable_variables)
        self.d_opt.apply_gradients(zip(d_grad, self.discriminator.trainable_variables))

        return {"g_loss": g_loss, "g_adv": g_adv, "g_seg": g_seg, "d_loss": d_loss}


###############################################################################
# 5. Vision Transformer (ViT) 用于分类 & 位置回归
###############################################################################
def mlp_transformer_block(x, hidden_units, dropout_rate, out_dim):
    for units in hidden_units:
        x = layers.Dense(units, activation=tf.nn.gelu)(x)
        x = layers.Dropout(dropout_rate)(x)
    x = layers.Dense(out_dim)(x)
    return x

class Patches(layers.Layer):
    def __init__(self, patch_size=16, **kwargs):
        super().__init__(**kwargs)
        self.patch_size = patch_size
    def call(self, images):
        batch_size = tf.shape(images)[0]
        patches = tf.image.extract_patches(
            images=images,
            sizes=[1, self.patch_size, self.patch_size, 1],
            strides=[1, self.patch_size, self.patch_size, 1],
            rates=[1,1,1,1],
            padding='VALID'
        )
        patch_dims = patches.shape[-1]
        patches = tf.reshape(patches, [batch_size, -1, patch_dims])
        return patches

    def get_config(self):
        config = super().get_config()
        config.update({"patch_size": self.patch_size})
        return config

class PatchEncoder(layers.Layer):
    def __init__(self, num_patches, projection_dim, **kwargs):
        super().__init__(**kwargs)
        self.num_patches = num_patches
        self.projection  = layers.Dense(units=projection_dim)
        self.position_embedding = layers.Embedding(
            input_dim=num_patches,
            output_dim=projection_dim
        )
    def call(self, patches):
        positions = tf.range(start=0, limit=self.num_patches, delta=1)
        encoded   = self.projection(patches) + self.position_embedding(positions)
        return encoded

    def get_config(self):
        config = super().get_config()
        config.update({
            "num_patches": self.num_patches,
            "projection_dim": self.projection.units
        })
        return config

def build_simple_vit(
    input_shape=(96,96,1),
    patch_size=16,
    num_heads=4,
    embed_dim=128,
    ff_dim=256,
    transformer_layers=3,
    num_classes=3
):
    inp = layers.Input(shape=input_shape)
    x = inp

    patches_layer = Patches(patch_size)
    patches = patches_layer(x)
    num_patches = (input_shape[0] // patch_size) * (input_shape[1] // patch_size)

    encoder = PatchEncoder(num_patches, embed_dim)
    x_enc   = encoder(patches)

    for _ in range(transformer_layers):
        x1 = layers.LayerNormalization(epsilon=1e-6)(x_enc)
        attention_output = layers.MultiHeadAttention(
            num_heads=num_heads, key_dim=embed_dim, dropout=0.1
        )(x1, x1)
        x2 = layers.Add()([attention_output, x_enc])

        x3 = layers.LayerNormalization(epsilon=1e-6)(x2)
        x3 = mlp_transformer_block(x3, [ff_dim], 0.1, embed_dim)
        x_enc = layers.Add()([x3, x2])

    rep = layers.LayerNormalization(epsilon=1e-6)(x_enc)
    rep = layers.GlobalAveragePooling1D()(rep)
    rep = layers.Dropout(0.5)(rep)

    cls_out = layers.Dense(num_classes, name='patch_cls')(rep)
    pos_out = layers.Dense(2, activation='sigmoid', name='patch_pos')(rep)
    return models.Model(inp, [cls_out, pos_out], name="CustomViT")


###############################################################################
# 6. 可视化函数（若需要可留用）。本实验不强制使用。
###############################################################################
def plot_sources_on_field(ax, field2d, sources, add_colorbar=True):
    vmin, vmax = np.percentile(field2d, [5, 95])
    img_handle = ax.imshow(field2d, cmap='turbo', vmin=vmin, vmax=vmax)
    for s in sources:
        tname = s[0]
        x0 = s[2]  # 行
        y0 = s[3]  # 列
        ax.plot(y0, x0, 'rx', ms=5, mew=1.5)
        ax.text(y0 + 2, x0 + 2, f"{tname}\n({x0:.1f},{y0:.1f})",
                color='white', fontsize=6,
                bbox=dict(facecolor='black', alpha=0.3, pad=1))
    ax.axis('off')
    return img_handle


###############################################################################
# ============ 噪声鲁棒性测试：逐点误差导出到Excel =============
###############################################################################
def test_noise_robustness(
    generator,        # 训练好的生成器(Attention UNet)
    vit_model,        # 训练好的ViT
    grid_size=128,
    T=5,
    num_test=200,
    out_json_path="noise_test_results.json"
):
    """
    在三种噪声类型(高斯/拉普拉斯/混合)、幅度0.005~0.05(步进0.005)下，
    测试 cGAN (IoU, Dice) 与 ViT (分类准确率, 定位RMSE)，并将结果保存到 JSON。
    同时，把逐点的定位误差输出到 Excel。
    """

    noise_types = ["gaussian", "laplacian", "mixed"]
    # 这里仅示例 0.005, 0.01, 0.015, 0.02 这四档 (你可改到0.05)
    noise_amplitudes = np.arange(0.005, 0.051, 0.005)

    results = {}
    type_map = {0: "dipole", 1: "line", 2: "quad"}

    # 用来收集每个源点的详细定位误差记录
    loc_error_records = []

    for nt in noise_types:
        results[nt] = {}
        for amp in noise_amplitudes:
            # 1) 生成测试数据
            X_test, Y_test, Sinfo_test = create_dataset_dynamic(
                num_samples=num_test,
                grid_size=grid_size,
                T=T,
                noise_type=nt,
                noise_amplitude=amp,
                do_augment=False
            )
            # 2) 使用 cGAN 预测
            preds_test = generator.predict(X_test, verbose=0)

            # ---- 计算 IoU & Dice （对整批数据的平均）----
            iou_list = []
            dice_list= []
            for i in range(num_test):
                iou_val = compute_iou(Y_test[i], preds_test[i])
                dice_val= compute_dice(Y_test[i], preds_test[i])
                iou_list.append(iou_val)
                dice_list.append(dice_val)
            mean_iou  = float(np.mean(iou_list))
            mean_dice = float(np.mean(dice_list))

            # ---- 使用 ViT 做分类和定位，并记录每个源点的误差 ----
            cls_correct = 0
            loc_errors  = []
            count_src   = 0

            for i in range(num_test):
                union_mask = np.max(Y_test[i], axis=-1).astype(np.uint8)
                num_l, _, stats, centroids = cv2.connectedComponentsWithStats(
                    union_mask, connectivity=8
                )

                # 逐个源：找最匹配的连通域来截取patch
                for src in Sinfo_test[i]:
                    stype_id = src[1]   # 0/1/2
                    x0_true  = src[2]  # 行坐标
                    y0_true  = src[3]  # 列坐标
                    count_src += 1

                    # 在连通域里找与 (x0_true,y0_true) 最近者
                    best_lb, best_d = None, 1e9
                    for lb in range(1, num_l):
                        # centroids[lb] = (cx, cy) => (列, 行)
                        cx, cy = centroids[lb]
                        dd = (cy - x0_true)**2 + (cx - y0_true)**2
                        if dd < best_d:
                            best_d = dd
                            best_lb = lb
                    if best_lb is None:
                        continue

                    # stats: [left(col), top(row), width, height]
                    x2 = stats[best_lb, cv2.CC_STAT_LEFT]   # col起点
                    y2 = stats[best_lb, cv2.CC_STAT_TOP]    # row起点
                    w2 = stats[best_lb, cv2.CC_STAT_WIDTH]  # col宽
                    h2 = stats[best_lb, cv2.CC_STAT_HEIGHT] # row高
                    if w2 < 2 or h2 < 2:
                        continue

                    # 提取子图并resize到 (96,96)
                    sub_img = X_test[i, y2:y2+h2, x2:x2+w2, :]  # (h2,w2,T)
                    sub_img_res = np.zeros((96, 96, T), dtype=np.float32)
                    for t_ in range(T):
                        tmp = cv2.resize(sub_img[..., t_], (96,96))
                        mm, ss = tmp.mean(), tmp.std() + 1e-6
                        tmp = (tmp - mm)/ss
                        sub_img_res[..., t_] = tmp
                    sub_img_res = np.expand_dims(sub_img_res, axis=0)

                    # =========== ViT推理 ===========
                    pred_cls_logits, pred_pos = vit_model.predict(sub_img_res, verbose=0)
                    pred_cls_id = np.argmax(pred_cls_logits[0])
                    px, py = pred_pos[0]  # px=行偏移, py=列偏移, 均在 [0,1]

                    # ---- 计算预测行/列坐标 ----
                    # row: y2 + px*h2
                    # col: x2 + py*w2
                    pred_row = y2 + px*h2
                    pred_col = x2 + py*w2

                    if pred_cls_id == stype_id:
                        cls_correct += 1

                    loc_err = math.sqrt((pred_row - x0_true)**2 + (pred_col - y0_true)**2)
                    loc_errors.append(loc_err)

                    # 记录到 loc_error_records
                    loc_error_records.append({
                        "noise_type"      : nt,
                        "noise_amp"       : amp,
                        "sample_idx"      : i,
                        "source_type_id"  : stype_id,
                        "source_type_str" : type_map.get(stype_id, "unknown"),
                        "true_row"        : x0_true,
                        "true_col"        : y0_true,
                        "pred_row"        : pred_row,
                        "pred_col"        : pred_col,
                        "loc_error"       : loc_err
                    })

            cls_acc  = float(cls_correct / count_src) if count_src>0 else 0.0
            rmse_val = float(np.sqrt(np.mean(np.square(loc_errors)))) if len(loc_errors)>0 else 0.0

            # 保存到 results
            results[nt][f"{amp:.3f}"] = {
                "IoU"       : mean_iou,
                "Dice"      : mean_dice,
                "cls_acc"   : cls_acc,
                "loc_rmse"  : rmse_val
            }

            print(f"[TEST] noise={nt}, amp={amp:.3f},",
                  f"IoU={mean_iou:.4f}, Dice={mean_dice:.4f},",
                  f"ACC={cls_acc:.4f}, RMSE={rmse_val:.4f}")

    # ========== 将逐点误差信息保存到 Excel =============
    df_err = pd.DataFrame(loc_error_records)
    out_xlsx_path = "outputs/pointwise_loc_error.xlsx"
    df_err.to_excel(out_xlsx_path, index=False)
    print(f"[INFO] Saved pointwise errors to Excel: {out_xlsx_path}")

    # 另存 JSON 汇总
    with open(out_json_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"[INFO] All summary results saved to {out_json_path}.")


###############################################################################
# 7. 主函数：训练/加载模型，及噪声鲁棒性测试
###############################################################################
def main():
    if not os.path.exists("outputs"):
        os.makedirs("outputs")

    # ---------------------------------------------------
    # 1) 准备数据 (如需重新训练cGAN和ViT)
    #    此处示例：生成50个样本, T=5, 分训练/测试
    # ---------------------------------------------------
    num_total = 50
    grid_size = 128
    T = 5

    print("[INFO] Generating the dataset ...")
    X_all, Y_all, Src_all = create_dataset_dynamic(
        num_samples=num_total,
        grid_size=grid_size,
        T=T,
        do_augment=True  # 随机翻转作为数据增强
    )

    idx_split = int(0.7 * num_total)
    X_train, Y_train = X_all[:idx_split], Y_all[:idx_split]
    X_test,  Y_test  = X_all[idx_split:], Y_all[idx_split:]
    Sinfo_tr, Sinfo_ts = Src_all[:idx_split], Src_all[idx_split:]
    print("[INFO] X_train:", X_train.shape, "Y_train:", Y_train.shape)
    print("[INFO] X_test :", X_test.shape,  "Y_test :",  Y_test.shape)

    # ---------------------------------------------------
    # 2) 构建并加载/训练 cGAN (Attention UNet + PatchGAN)
    # ---------------------------------------------------
    gen_path = "outputs/attention_unet_gen_dynamic_v2.keras"
    adv_bce = BinaryCrossentropy(from_logits=True)

    generator = build_attention_unet(
        input_shape=(grid_size, grid_size, T),
        out_channels=T
    )
    discriminator = build_patchgan_discriminator((grid_size, grid_size, 2*T))
    cgan = MagneticDistortCGAN(generator, discriminator, lambda_seg=12.0)

    if os.path.exists(gen_path):
        print("[INFO] Loading pretrained generator from:", gen_path)
        generator = tf.keras.models.load_model(gen_path, compile=False)
    else:
        print("[INFO] Training cGAN from scratch ...")
        cgan.compile(
            g_opt=Adam(1e-4, beta_1=0.5),
            d_opt=Adam(1e-4, beta_1=0.5),
            seg_loss_fn=combined_bce_dice_loss,  # 或 focal_bce_loss
            adv_loss_fn=adv_bce
        )
        cgan_history = cgan.fit(X_train, Y_train, batch_size=4, epochs=200)
        generator.save(gen_path)

        # 简单画图
        plt.figure()
        plt.plot(cgan_history.history['g_loss'], label='g_loss')
        plt.plot(cgan_history.history['g_adv'], label='g_adv')
        plt.plot(cgan_history.history['g_seg'], label='g_seg')
        plt.plot(cgan_history.history['d_loss'], label='d_loss')
        plt.title("cGAN Training Curves")
        plt.legend()
        plt.savefig("outputs/cgan_training_curves.png")
        plt.close()

    # ---------------------------------------------------
    # 3) 构建并加载/训练 ViT (分类+位置)
    # ---------------------------------------------------
    vit_path = "outputs/vit_dynamic_v2.keras"
    vit = build_simple_vit(
        input_shape=(96, 96, T),
        patch_size=16,
        num_heads=8,
        embed_dim=256,
        ff_dim=512,
        transformer_layers=6
    )
    vit.compile(
        optimizer=Adam(1e-4),
        loss={
            "patch_cls": tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
            "patch_pos": tf.keras.losses.MeanSquaredError()
        },
        loss_weights={"patch_cls": 2.0, "patch_pos": 0.05},
        metrics={"patch_cls": "accuracy"}
    )

    # ~~~ 准备ViT训练所需的patch数据 (与脚本逻辑一致) ~~~
    patch_imgs, patch_cls, patch_pos = [], [], []
    for i in range(len(X_train)):
        union_mask = np.max(Y_train[i], axis=-1).astype(np.uint8)
        num_l, _, stats, centroids = cv2.connectedComponentsWithStats(union_mask, connectivity=8)

        # 与真源匹配
        for src in Sinfo_tr[i]:
            stype_id = src[1]  # 0/1/2
            x0, y0 = src[2], src[3]  # x0=行, y0=列

            # 找最匹配连通域
            best_lb, best_d = None, 1e9
            for lb in range(1, num_l):
                cx, cy = centroids[lb]  # cx=列, cy=行
                dd = (cy - x0)**2 + (cx - y0)**2
                if dd < best_d:
                    best_d = dd
                    best_lb = lb
            if best_lb is None:
                continue

            # stats: [left=col, top=row, width=colW, height=rowH]
            x2 = stats[best_lb, cv2.CC_STAT_LEFT]   # col
            y2 = stats[best_lb, cv2.CC_STAT_TOP]    # row
            w2 = stats[best_lb, cv2.CC_STAT_WIDTH]
            h2 = stats[best_lb, cv2.CC_STAT_HEIGHT]
            if w2<2 or h2<2:
                continue

            sub_img = X_train[i, y2:y2+h2, x2:x2+w2, :]
            sub_res = np.zeros((96,96, T), dtype=np.float32)
            for t_ in range(T):
                tmp = cv2.resize(sub_img[..., t_], (96, 96))
                mm, ss = tmp.mean(), tmp.std() + 1e-6
                tmp = (tmp - mm) / ss
                sub_res[..., t_] = tmp

            # row offset
            roff = (x0 - y2)/(h2+1e-6)
            # col offset
            coff = (y0 - x2)/(w2+1e-6)

            patch_imgs.append(sub_res)
            patch_cls.append(stype_id)
            patch_pos.append([roff, coff])

    patch_imgs = np.array(patch_imgs, dtype=np.float32)
    patch_cls  = np.array(patch_cls, dtype=np.int32)
    patch_pos  = np.array(patch_pos, dtype=np.float32)

    print("[INFO] patch_imgs:", patch_imgs.shape,
          "patch_cls:", patch_cls.shape,
          "patch_pos:", patch_pos.shape)

    # 拆分70:30 作为验证
    idxs = np.arange(len(patch_imgs))
    np.random.shuffle(idxs)
    spn = int(0.7 * len(idxs))
    id_tr = idxs[:spn]
    id_vl = idxs[spn:]

    es = EarlyStopping(monitor="val_patch_cls_accuracy", patience=30, restore_best_weights=True)
    rlp= ReduceLROnPlateau(monitor="val_loss", factor=0.9, patience=20, min_lr=1e-9)

    if os.path.exists(vit_path):
        print("[INFO] Loading pretrained ViT from:", vit_path)
        vit = tf.keras.models.load_model(
            vit_path,
            custom_objects={"Patches": Patches, "PatchEncoder": PatchEncoder},
            compile=False
        )
        # 重新compile
        vit.compile(
            optimizer=Adam(1e-4),
            loss={
                "patch_cls": tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
                "patch_pos": tf.keras.losses.MeanSquaredError()
            },
            loss_weights={"patch_cls": 2.0, "patch_pos": 0.05},
            metrics={"patch_cls": "accuracy"}
        )
    else:
        if len(id_tr) > 10:
            print("[INFO] Training ViT from scratch ...")
            vit_history = vit.fit(
                patch_imgs[id_tr],
                {"patch_cls": patch_cls[id_tr], "patch_pos": patch_pos[id_tr]},
                validation_data=(
                    patch_imgs[id_vl],
                    {"patch_cls": patch_cls[id_vl], "patch_pos": patch_pos[id_vl]}
                ),
                epochs=150,
                batch_size=8,
                callbacks=[es, rlp]
            )
            vit.save(vit_path)

            # 简单画下训练曲线
            plt.figure()
            plt.plot(vit_history.history['loss'], label='loss')
            plt.plot(vit_history.history['patch_cls_loss'], label='patch_cls_loss')
            plt.plot(vit_history.history['patch_pos_loss'], label='patch_pos_loss')
            plt.plot(vit_history.history['patch_cls_accuracy'], label='patch_cls_acc')
            plt.legend()
            plt.title("ViT Training Curves")
            plt.savefig("outputs/vit_training_curves.png")
            plt.close()

    # ---------------------------------------------------
    # 4) 正式进行“噪声鲁棒性”测试(含导出Excel)
    # ---------------------------------------------------
    test_noise_robustness(
        generator=generator,
        vit_model=vit,
        grid_size=grid_size,
        T=T,
        num_test=500,  # 每种噪声配置生成20个测试
        out_json_path="outputs/noise_test_results.json"
    )

    print("[INFO] Done. All experiment results have been saved.")


if __name__ == "__main__":
    main()
