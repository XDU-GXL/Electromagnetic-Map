import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

def analyze_error_distribution_all_in_one(
        excel_path="pointwise_loc_error.xlsx",
        target_quantiles=[0.5, 0.8, 0.9, 0.95]
):
    """
    将所有噪声类型的误差CDF曲线绘制在同一张图中，并将所有信息整合到一个图例中显示，
    图例中包含：噪声类型、幅度范围、该类型在CDF=0.9处对应的最小/最大误差交点横坐标，
    以及0.9 CDF的水平线。
    """

    # 1. 读取 Excel 文件
    df_err = pd.read_excel(excel_path)
    # 预期列包括：
    # ["noise_type", "noise_amp", "sample_idx",
    #  "source_type_id", "source_type_str",
    #  "true_row", "true_col", "pred_row", "pred_col", "loc_error"]

    # 2. 分组计算统计量（此处仅用于打印查看统计信息）
    group_cols = ["noise_type", "noise_amp"]
    grouped = df_err.groupby(group_cols)

    records = []
    for (ntype, amp), subdf in grouped:
        errors = subdf["loc_error"].values
        stats = {"noise_type": ntype, "noise_amp": amp, "count": len(errors)}
        for q in target_quantiles:
            q_val = np.percentile(errors, q * 100)
            stats[f"Q{int(q * 100)}"] = q_val
        stats["mean"] = np.mean(errors)
        stats["max"] = np.max(errors)
        records.append(stats)

    result_df = pd.DataFrame(records)
    result_df.sort_values(by=["noise_type", "noise_amp"], inplace=True)

    print("\n[Quantile Statistics for Errors]:")
    print(result_df)

    # 3. 绘图：将所有噪声类型的CDF曲线绘制在同一图中
    unique_noise_types = df_err["noise_type"].unique()
    fig, ax = plt.subplots(figsize=(10, 6))
    color_list = ["blue", "orange", "green", "red", "purple", "brown"]

    # 用于统一设置x轴范围
    global_x_vals = []
    # 用于保存每个噪声类型的图例信息
    legend_entries = []

    for idx_ntype, ntype in enumerate(unique_noise_types):
        subdf_noise = df_err[df_err["noise_type"] == ntype]
        unique_amps = np.sort(subdf_noise["noise_amp"].unique())
        base_color = color_list[idx_ntype % len(color_list)]
        x_val_0_9_list = []

        # 遍历同一噪声类型下不同的噪声幅度
        for amp in unique_amps:
            subdf = subdf_noise[subdf_noise["noise_amp"] == amp]
            errors = np.sort(subdf["loc_error"].values)
            cdf_y = np.arange(1, len(errors) + 1) / len(errors)
            x_val_0_9 = np.interp(0.9, cdf_y, errors)
            x_val_0_9_list.append(x_val_0_9)
            global_x_vals.extend(errors)
            # 绘制每条CDF曲线（同一噪声类型统一颜色，不同幅度曲线区分线宽或透明度即可）
            ax.plot(errors, cdf_y,
                    label=f"amp={amp}",
                    linewidth=1.5,
                    alpha=0.8,
                    color=base_color)

        # 计算该噪声类型在CDF=0.9处的最小和最大误差交点
        global_min_0_9 = min(x_val_0_9_list)
        global_max_0_9 = max(x_val_0_9_list)
        # 绘制对应的垂直虚线和交点标记
        ax.axvline(x=global_min_0_9, color=base_color, linestyle='--', linewidth=2, alpha=0.7)
        ax.axvline(x=global_max_0_9, color=base_color, linestyle='--', linewidth=2, alpha=0.7)
        ax.plot(global_min_0_9, 0.9, marker='o', markersize=7, color=base_color)
        ax.plot(global_max_0_9, 0.9, marker='o', markersize=7, color=base_color)

        # 计算该噪声类型的噪声幅度范围
        amp_range = (min(unique_amps), max(unique_amps))
        # 构造图例文本信息
        legend_label = f"Noise: {ntype}, Amp: {amp_range[0]}~{amp_range[1]}, Error: {global_min_0_9:.2f}/{global_max_0_9:.2f}"
        # 用虚线作为该噪声类型的代表符号
        legend_handle = Line2D([0], [0], color=base_color, lw=2, linestyle='--')
        legend_entries.append((legend_handle, legend_label))

    # 绘制0.9 CDF的水平线
    ax.axhline(y=0.9, color='gray', linestyle='-', linewidth=1.5)
    # 将0.9 CDF也加入图例
    legend_entries.append((Line2D([0], [0], color='gray', lw=1.5, linestyle='-'), "0.9 CDF"))

    # 设置全局x轴范围（可根据需要适当留白）
    if global_x_vals:
        x_min, x_max = min(global_x_vals), max(global_x_vals)
        ax.set_xlim(x_min, x_max)
    ax.set_xlim(0, 10)
    ax.set_ylim(0.4, 0.95)
    ax.set_xlabel("Location Error", fontsize=12)
    ax.set_ylabel("CDF (Probability of error ≤ x)", fontsize=12)
    ax.set_title("Error Cumulative Distribution (All Noise Types)", fontsize=14)


    # 生成单一图例
    handles, labels = zip(*legend_entries)
    ax.legend(handles, labels, loc='lower left', fontsize=10)

    plt.tight_layout()
    plt.savefig("error_distribution_all_in_one.svg", format="svg", dpi=300)
    plt.show()

    return result_df


if __name__ == "__main__":
    df_result = analyze_error_distribution_all_in_one(
        excel_path="pointwise_loc_error.xlsx",
        target_quantiles=[0.5, 0.8, 0.9, 0.95]
    )
