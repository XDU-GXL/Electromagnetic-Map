import json
import numpy as np
import matplotlib.pyplot as plt


def plot_cgan_metrics(data, save_path='cgan_metrics.svg'):
    """
    绘制 cGAN Metrics vs Noise Level
    左轴：IoU
    右轴：Dice
    """
    methods = ['gaussian', 'laplacian', 'mixed']

    # 为每个方法选一些配色、线型，仅示例，可自行调整
    style_map = {
        'gaussian': ('blue', 'o-', 'gaussian'),
        'laplacian': ('orange', 's--', 'laplacian'),
        'mixed': ('green', '^-.', 'mixed')
    }

    # figsize可以根据需要调整，dpi对SVG矢量图主要影响文字、点标记等清晰度
    fig, ax1 = plt.subplots(figsize=(6, 4), dpi=300)
    ax2 = ax1.twinx()  # 右侧y轴

    for method in methods:
        noise_levels = sorted(data[method].keys(), key=lambda x: float(x))
        noise_arr = np.array([float(n) for n in noise_levels])

        iou_values = [data[method][n]['IoU'] for n in noise_levels]
        dice_values = [data[method][n]['Dice'] for n in noise_levels]

        color, line_style, lbl = style_map[method]

        # 绘制 IoU (左轴)
        ax1.plot(
            noise_arr,
            iou_values,
            line_style,
            color=color,
            label=f'{lbl} IoU'
        )
        # 绘制 Dice (右轴)
        ax2.plot(
            noise_arr,
            dice_values,
            line_style,
            color=color,
            alpha=0.5,
            label=f'{lbl} Dice'
        )

    ax1.set_xlabel('Noise Level')
    ax1.set_ylabel('cGAN_IoU')
    ax2.set_ylabel('cGAN_Dice')
    ax1.set_title('cGAN Metrics vs Noise Level')

    # 合并图例
    lines_1, labels_1 = ax1.get_legend_handles_labels()
    lines_2, labels_2 = ax2.get_legend_handles_labels()
    ax1.legend(lines_1 + lines_2, labels_1 + labels_2, loc='best')

    # 去掉网格线
    ax1.grid(False)
    ax2.grid(False)

    plt.tight_layout()
    # 保存为SVG
    plt.savefig(save_path, format='svg')
    plt.show()


def plot_vit_metrics(data, save_path='vit_metrics.svg'):
    """
    绘制 ViT Metrics vs Noise Level
    左轴：Accuracy
    右轴：RMSE
    """
    methods = ['gaussian', 'laplacian', 'mixed']

    style_map = {
        'gaussian': ('blue', 'o-', 'gaussian'),
        'laplacian': ('orange', 's--', 'laplacian'),
        'mixed': ('green', '^-.', 'mixed')
    }

    fig, ax1 = plt.subplots(figsize=(6, 4), dpi=300)
    ax2 = ax1.twinx()

    for method in methods:
        noise_levels = sorted(data[method].keys(), key=lambda x: float(x))
        noise_arr = np.array([float(n) for n in noise_levels])

        acc_values = [data[method][n]['cls_acc'] for n in noise_levels]
        rmse_values = [data[method][n]['loc_rmse'] for n in noise_levels]

        color, line_style, lbl = style_map[method]

        # Accuracy (左轴)
        ax1.plot(
            noise_arr,
            acc_values,
            line_style,
            color=color,
            label=f'{lbl} Accuracy'
        )
        # RMSE (右轴)
        ax2.plot(
            noise_arr,
            rmse_values,
            line_style,
            color=color,
            alpha=0.5,
            label=f'{lbl} RMSE'
        )

    ax1.set_xlabel('Noise Level')
    ax1.set_ylabel('ViT_Accuracy')
    ax2.set_ylabel('ViT_RMSE')
    ax1.set_title('ViT Metrics vs Noise Level')

    lines_1, labels_1 = ax1.get_legend_handles_labels()
    lines_2, labels_2 = ax2.get_legend_handles_labels()
    ax1.legend(lines_1 + lines_2, labels_1 + labels_2, loc='best')

    # 去掉网格线
    ax1.grid(False)
    ax2.grid(False)

    plt.tight_layout()
    plt.savefig(save_path, format='svg')
    plt.show()


if __name__ == '__main__':
    with open('noise_test_results.json', 'r', encoding='utf-8') as f:
        data = json.load(f)

    plot_cgan_metrics(data, save_path='cgan_metrics.svg')
    plot_vit_metrics(data, save_path='vit_metrics.svg')
