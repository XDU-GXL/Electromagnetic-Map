#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import math
import random
import json
import numpy as np
import cv2

# 为了使用GPU上的并行操作，这里继续保留cupy，但需确认环境已安装 cupy
import cupy as cp
import cupyx.scipy.ndimage as ndi

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.losses import BinaryCrossentropy
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras import backend as K

from sklearn.metrics import confusion_matrix

###############################################################################
# 一、常用辅助函数
###############################################################################

def compute_iou(y_true, y_pred):
    """计算 IoU."""
    y_true_bin = (y_true > 0.5).astype(np.float32)
    y_pred_bin = (y_pred > 0.5).astype(np.float32)
    intersection = np.sum(y_true_bin * y_pred_bin)
    union = np.sum(y_true_bin) + np.sum(y_pred_bin) - intersection
    return (intersection + 1e-6) / (union + 1e-6)

def dice_coef_np(y_true, y_pred, smooth=1e-6):
    """Numpy 版 Dice 系数."""
    y_true_f = (y_true.flatten()>0.5).astype(np.float32)
    y_pred_f = (y_pred.flatten()>0.5).astype(np.float32)
    inter = np.sum(y_true_f * y_pred_f)
    den   = np.sum(y_true_f) + np.sum(y_pred_f)
    return (2.*inter+smooth)/(den+smooth)

def dipole_field_2d_vector(grid_size, x0, y0, moment, inc_deg, dec_deg):
    """
    使用 cupy 向量化计算偶极子场: Bz ~ (M·r)/r^3.
    """
    inc = cp.radians(inc_deg)
    dec = cp.radians(dec_deg)
    Mx = moment * cp.cos(inc) * cp.cos(dec)
    My = moment * cp.cos(inc) * cp.sin(dec)

    ix = cp.arange(grid_size, dtype=cp.float32)
    iy = cp.arange(grid_size, dtype=cp.float32)
    rx, ry = cp.meshgrid(ix, iy, indexing='ij')  # shape=(grid_size,grid_size)

    rx = rx - x0
    ry = ry - y0
    r_sq = rx*rx + ry*ry + 1e-12
    r_3  = r_sq**1.5
    dotMr= Mx*rx + My*ry
    return dotMr / r_3

def line_current_field_2d_vector(grid_size, x0, y0, current):
    """
    使用 cupy 向量化计算线电流场 (简化): Bz ~ current / r
    """
    ix = cp.arange(grid_size, dtype=cp.float32)
    iy = cp.arange(grid_size, dtype=cp.float32)
    rx, ry = cp.meshgrid(ix, iy, indexing='ij')
    rx = rx - x0
    ry = ry - y0
    rr = cp.sqrt(rx*rx + ry*ry + 1e-12)
    return current / rr

def quadrupole_field_2d_vector(grid_size, x0, y0, strength):
    """
    使用 cupy 向量化计算四极子场（简化）:
    Bz ~ (2*ry^2 - r^2)/r^3
    """
    ix = cp.arange(grid_size, dtype=cp.float32)
    iy = cp.arange(grid_size, dtype=cp.float32)
    rx, ry = cp.meshgrid(ix, iy, indexing='ij')
    rx = rx - x0
    ry = ry - y0
    r_sq= rx*rx + ry*ry + 1e-12
    r_3 = r_sq**1.5
    return strength*((2.*ry*ry - r_sq)/r_3)

def generate_random_sources_with_overlap_constraint(
    grid_size,
    T,
    overlap_range=(0.0, 0.1),
    max_tries=500
):
    """
    根据“重叠度”区间 overlap_range 来筛选源的位置与数量:
      OverlapFactor = n / (1 + avg_dist)

    - n: 源的数量
    - avg_dist: 所有源之间两两距离的平均值

    overlap_range: (min_val, max_val) 指定OveralpFactor应落在的区间。
    max_tries: 最多尝试多少次随机放置以满足条件.

    返回:
      sources_params: 列表，每个元素记录 (stype, x0, y0, 其他随机参数)
    """
    # 先简单限定一下源的数量上下限范围
    # 如果希望更精准控制，也可以根据 overlap_range 动态适配
    possible_n = range(3, 9)  # [2..10] 个源之间
    min_overlap, max_overlap = overlap_range

    for _ in range(max_tries):
        n_sources = random.choice(possible_n)
        # 随机生成 n 个位置
        positions = []
        for _ in range(n_sources):
            x0 = random.uniform(0, grid_size)
            y0 = random.uniform(0, grid_size)
            positions.append((x0, y0))

        # 计算平均两两距离
        dists = []
        for i in range(n_sources):
            for j in range(i+1, n_sources):
                dx = positions[i][0] - positions[j][0]
                dy = positions[i][1] - positions[j][1]
                dists.append(math.hypot(dx, dy))
        if len(dists)==0:
            # n_sources=1时不会出现，但这里最小2，所以不大会发生
            avg_dist = grid_size/2.
        else:
            avg_dist = sum(dists)/len(dists)

        overlap_factor = n_sources / (1.0 + avg_dist)
        # 判断是否在期望区间内
        if overlap_factor>=min_overlap and overlap_factor<=max_overlap:
            # 生成源的详细参数
            # stype=0,1,2 => dipole/line/quad
            # 其余随机参数保持与原先一样
            source_list = []
            for i in range(n_sources):
                stype = random.randint(0,2)
                (x0, y0) = positions[i]
                if stype == 0:  # dipole
                    moment_base = random.uniform(0.06, 0.20)
                    inc = random.uniform(-30, 30)
                    dec = random.uniform(0, 360)
                    freq = random.uniform(0.5, 2.0)
                    phase= random.uniform(0, 2*math.pi)
                    amps = []
                    for t_ in range(T):
                        scale = 0.5 + 0.5*math.sin(freq*(t_ + phase))
                        amps.append(scale * moment_base)
                    source_list.append(("dipole", stype, x0, y0, inc, dec, amps))

                elif stype == 1:  # line
                    length = random.uniform(5, 20)
                    current_base= random.uniform(0.06, 0.20)
                    freq = random.uniform(0.5, 2.0)
                    phase= random.uniform(0, 2*math.pi)
                    amps = []
                    for t_ in range(T):
                        scale = 0.5 + 0.5*math.cos(freq*(t_ + phase))
                        amps.append(scale * current_base)
                    source_list.append(("line", stype, x0, y0, length, amps))

                else:  # quad
                    strength_base = random.uniform(0.06, 0.20)
                    freq = random.uniform(0.5, 2.0)
                    phase= random.uniform(0, 2*math.pi)
                    amps = []
                    for t_ in range(T):
                        scale = 0.5 + 0.5*math.sin(freq*(t_ + phase))
                        amps.append(scale * strength_base)
                    source_list.append(("quad", stype, x0, y0, amps))

            return source_list

    # 如果尝试 max_tries 次都失败，返回一个空表以表示“没生成成功”
    return []

def simulate_magnetic_distortion_2d_dynamic_with_overlap(
    grid_size=128,
    background_strength=0.58,
    threshold_ratio=0.035,
    T=5,
    overlap_range=(0.0, 0.1),
):
    """
    与原simulate_magnetic_distortion_2d_dynamic类似，但在源的位置/数量上
    通过 generate_random_sources_with_overlap_constraint 来控制重叠度。
    """
    # 先生成符合指定overlap的源参数
    sources_params = generate_random_sources_with_overlap_constraint(
        grid_size=grid_size,
        T=T,
        overlap_range=overlap_range
    )
    if len(sources_params)==0:
        # 如果确实没能满足筛选，返回 None
        return None, None, []

    # 背景随机扰动
    bg_variation = 0.005 * cp.random.randn(grid_size, grid_size).astype(cp.float32)
    base_bg      = background_strength + bg_variation

    # 初始化 T 帧的场：每帧先是相同的 base_bg
    frames_field = cp.tile(base_bg[None, ...], (T, 1, 1))  # shape=(T,H,W)

    # 依次将各源对每一帧的贡献叠加
    for sp in sources_params:
        if sp[0] == 'dipole':
            x0, y0 = sp[2], sp[3]
            inc, dec = sp[4], sp[5]
            amp_list = sp[6]
            for t_ in range(T):
                field_add = dipole_field_2d_vector(grid_size, x0, y0, amp_list[t_], inc, dec)
                frames_field[t_] += field_add
        elif sp[0] == 'line':
            x0, y0 = sp[2], sp[3]
            amp_list = sp[5]
            for t_ in range(T):
                field_add = line_current_field_2d_vector(grid_size, x0, y0, amp_list[t_])
                frames_field[t_] += field_add
        else:  # quad
            x0, y0 = sp[2], sp[3]
            amp_list = sp[4]
            for t_ in range(T):
                field_add = quadrupole_field_2d_vector(grid_size, x0, y0, amp_list[t_])
                frames_field[t_] += field_add

    # 生成mask
    mask_3d_cp = cp.zeros_like(frames_field, dtype=cp.uint8)
    thr_value  = threshold_ratio * background_strength
    for t_ in range(T):
        diff_t = cp.abs(frames_field[t_] - background_strength)
        mask_3d_cp[t_] = (diff_t >= thr_value).astype(cp.uint8)

    # 转回CPU
    field_3d = frames_field.get().astype(np.float32)  # (T,H,W)
    mask_3d  = mask_3d_cp.get().astype(np.uint8)      # (T,H,W)

    # 简化记录源信息: 仅存( type, stype, x0, y0, 其余平均幅度... )
    final_srcs = []
    for sp in sources_params:
        if sp[0] == 'dipole':
            avg_m = sum(sp[6]) / len(sp[6])
            final_srcs.append((sp[0], sp[1], sp[2], sp[3], avg_m, sp[4], sp[5]))
        elif sp[0] == 'line':
            avg_c = sum(sp[5]) / len(sp[5])
            final_srcs.append((sp[0], sp[1], sp[2], sp[3], sp[4], avg_c))
        else:
            avg_s = sum(sp[4]) / len(sp[4])
            final_srcs.append((sp[0], sp[1], sp[2], sp[3], avg_s))

    return field_3d, mask_3d, final_srcs


def create_dataset_for_overlap_test(
    num_samples=100,
    grid_size=128,
    T=5,
    overlap_level="low"
):
    """
    按指定overlap_level生成数据集.
    overlap_level 可取 "low"/"medium"/"high"
    返回: X, Y, sources_info
      其中 X.shape=[N,H,W,T], Y.shape=[N,H,W,T]
    """
    # 这里为了演示，可以定义不同区间:
    # 也可根据自己需求改为更细的区间。
    overlap_ranges = {
        "very_low": (0.1, 0.22),
        "low":     (0.22, 0.34),
        "medium":  (0.34, 0.46),
        "high":    (0.46, 0.58),
        "very_high": (0.58, 0.7)
    }
    if overlap_level not in overlap_ranges:
        raise ValueError(f"Unknown overlap level: {overlap_level}")
    ov_min, ov_max = overlap_ranges[overlap_level]

    X_list, Y_list, Sinfo_list = [], [], []
    count = 0
    tries = 0
    while count < num_samples and tries < num_samples*5:
        tries += 1
        field_3d, mask_3d, srcs = simulate_magnetic_distortion_2d_dynamic_with_overlap(
            grid_size=grid_size,
            background_strength=0.58,
            threshold_ratio=0.035,
            T=T,
            overlap_range=(ov_min, ov_max)
        )
        if field_3d is None:
            continue
        # (T,H,W)->(H,W,T)
        f3d_hw = np.transpose(field_3d, (1,2,0))
        m3d_hw = np.transpose(mask_3d, (1,2,0))
        X_list.append(f3d_hw)
        Y_list.append(m3d_hw)
        Sinfo_list.append(srcs)
        count += 1
    X = np.array(X_list, dtype=np.float32)
    Y = np.array(Y_list, dtype=np.float32)
    return X, Y, Sinfo_list


###############################################################################
# 二、加载模型（已训练好的 Generator 和 ViT）
###############################################################################
def build_attention_unet(input_shape=(128,128,1), out_channels=1):
    """
    与原始脚本基本一致；仅保留用于加载模型结构时需要。
    """
    inp = layers.Input(input_shape)
    c1 = layers.Conv2D(64, 3, padding='same', activation='relu')(inp)
    c1 = layers.Conv2D(64, 3, padding='same', activation='relu')(c1)
    p1 = layers.MaxPooling2D(2)(c1)

    c2 = layers.Conv2D(128, 3, padding='same', activation='relu')(p1)
    c2 = layers.Conv2D(128, 3, padding='same', activation='relu')(c2)
    p2 = layers.MaxPooling2D(2)(c2)

    c3 = layers.Conv2D(256, 3, padding='same', activation='relu')(p2)
    c3 = layers.Conv2D(256, 3, padding='same', activation='relu')(c3)
    p3 = layers.MaxPooling2D(2)(c3)

    c4 = layers.Conv2D(512, 3, padding='same', activation='relu')(p3)
    c4 = layers.Conv2D(512, 3, padding='same', activation='relu')(c4)

    def attention_block(x, g, inter_channels):
        theta_x = layers.Conv2D(inter_channels, 2, strides=2, padding='same')(x)
        phi_g   = layers.Conv2D(inter_channels, 1, strides=1, padding='same')(g)
        add_xg  = layers.add([theta_x, phi_g])
        act_xg  = layers.Activation('relu')(add_xg)
        psi     = layers.Conv2D(1, 1, padding='same')(act_xg)
        psi     = layers.Activation('sigmoid')(psi)
        psi_up  = layers.Conv2DTranspose(1, 2, strides=2, padding='same')(psi)
        return layers.multiply([x, psi_up])

    g3   = layers.Conv2D(256, 1, activation='relu')(c4)
    att3 = attention_block(c3, g3, 256)
    u3   = layers.Conv2DTranspose(256, 2, strides=2, padding='same')(c4)
    u3   = layers.concatenate([u3, att3], axis=-1)
    cc3  = layers.Conv2D(256, 3, padding='same', activation='relu')(u3)
    cc3  = layers.Conv2D(256, 3, padding='same', activation='relu')(cc3)

    g2   = layers.Conv2D(128, 1, activation='relu')(cc3)
    att2 = attention_block(c2, g2, 128)
    u2   = layers.Conv2DTranspose(128, 2, strides=2, padding='same')(cc3)
    u2   = layers.concatenate([u2, att2], axis=-1)
    cc2  = layers.Conv2D(128, 3, padding='same', activation='relu')(u2)
    cc2  = layers.Conv2D(128, 3, padding='same', activation='relu')(cc2)

    g1   = layers.Conv2D(64, 1, activation='relu')(cc2)
    att1 = attention_block(c1, g1, 64)
    u1   = layers.Conv2DTranspose(64, 2, strides=2, padding='same')(cc2)
    u1   = layers.concatenate([u1, att1], axis=-1)
    cc1  = layers.Conv2D(64, 3, padding='same', activation='relu')(u1)
    cc1  = layers.Conv2D(64, 3, padding='same', activation='relu')(cc1)

    outp = layers.Conv2D(out_channels, 1, activation='sigmoid')(cc1)
    return models.Model(inp, outp, name='AttentionUNet')

class Patches(layers.Layer):
    def __init__(self, patch_size=16, **kwargs):
        super().__init__(**kwargs)
        self.patch_size = patch_size
    def call(self, images):
        # images: (batch,H,W,C)
        batch_size = tf.shape(images)[0]
        patches = tf.image.extract_patches(
            images=images,
            sizes=[1, self.patch_size, self.patch_size, 1],
            strides=[1, self.patch_size, self.patch_size, 1],
            rates=[1,1,1,1],
            padding='VALID'
        )
        patch_dims = patches.shape[-1]
        patches = tf.reshape(patches, [batch_size, -1, patch_dims])
        return patches
    def get_config(self):
        config = super().get_config()
        config.update({"patch_size": self.patch_size})
        return config

class PatchEncoder(layers.Layer):
    def __init__(self, num_patches, projection_dim, **kwargs):
        super().__init__(**kwargs)
        self.num_patches = num_patches
        self.projection  = layers.Dense(units=projection_dim)
        self.position_embedding = layers.Embedding(
            input_dim=num_patches,
            output_dim=projection_dim
        )
    def call(self, patches):
        positions = tf.range(start=0, limit=self.num_patches, delta=1)
        encoded   = self.projection(patches) + self.position_embedding(positions)
        return encoded
    def get_config(self):
        config = super().get_config()
        config.update({
            "num_patches": self.num_patches,
            "projection_dim": self.projection.units
        })
        return config

def build_simple_vit(
    input_shape=(96,96,1),
    patch_size=16,
    num_heads=4,
    embed_dim=128,
    ff_dim=256,
    transformer_layers=3,
    num_classes=3
):
    """
    与原始脚本一致，这里仅为加载权重时用。
    """
    def mlp_transformer_block(x, hidden_units, dropout_rate, out_dim):
        for units in hidden_units:
            x = layers.Dense(units, activation=tf.nn.gelu)(x)
            x = layers.Dropout(dropout_rate)(x)
        x = layers.Dense(out_dim)(x)
        return x

    inp = layers.Input(shape=input_shape)
    x = inp

    patches_layer = Patches(patch_size)
    patches = patches_layer(x)
    num_patches = (input_shape[0] // patch_size) * (input_shape[1] // patch_size)

    encoder = PatchEncoder(num_patches, embed_dim)
    x_enc   = encoder(patches)

    for _ in range(transformer_layers):
        x1 = layers.LayerNormalization(epsilon=1e-6)(x_enc)
        attention_output = layers.MultiHeadAttention(
            num_heads=num_heads, key_dim=embed_dim, dropout=0.1
        )(x1, x1)
        x2 = layers.Add()([attention_output, x_enc])

        x3 = layers.LayerNormalization(epsilon=1e-6)(x2)
        x3 = mlp_transformer_block(x3, [ff_dim], 0.1, embed_dim)
        x_enc = layers.Add()([x3, x2])

    rep = layers.LayerNormalization(epsilon=1e-6)(x_enc)
    rep = layers.GlobalAveragePooling1D()(rep)
    rep = layers.Dropout(0.5)(rep)

    cls_out = layers.Dense(num_classes, name='patch_cls')(rep)
    pos_out = layers.Dense(2, activation='sigmoid', name='patch_pos')(rep)
    return models.Model(inp, [cls_out, pos_out], name="CustomViT")


###############################################################################
# 三、可视化函数 (与原始代码相同)
###############################################################################
def plot_sources_on_field(ax, field2d, sources, vmin=None, vmax=None):
    if vmin is None or vmax is None:
        vmin, vmax = np.percentile(field2d, [5,95])
    ax.imshow(field2d, cmap='turbo', vmin=vmin, vmax=vmax)
    for s in sources:
        tname = s[0]
        x0 = s[2]
        y0 = s[3]
        ax.plot(y0, x0, 'rx', ms=5, mew=1.5)
        ax.text(y0+2, x0+2, f"{tname}\n({x0:.1f},{y0:.1f})",
                color='white', fontsize=6,
                bbox=dict(facecolor='black', alpha=0.3, pad=1))
    ax.axis('off')

def visualize_output_1(X, Y, Sinfo, out_dir="outputs/output_1", count=10):
    """原始数据(标注源信息) + GT mask，并在原始数据上标记简单SNR."""
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)
    indices = np.random.choice(len(X), size=min(count, len(X)), replace=False)
    for idx_num, i in enumerate(indices):
        field_hw_t = X[i]  # (H,W,T)
        mask_hw_t  = Y[i]  # (H,W,T)
        sources    = Sinfo[i]
        H, W, T = field_hw_t.shape
        plt.figure(figsize=(3*T, 6))
        for t_ in range(T):
            plt.subplot(2, T, t_+1)
            fm_ = field_hw_t[..., t_]
            plot_sources_on_field(plt.gca(), fm_, sources)
            # 计算SNR：均值/标准差
            snr = np.mean(fm_) / (np.std(fm_) + 1e-6)
            plt.text(5, 15, f"SNR: {snr:.2f}", color="yellow", fontsize=6,
                     bbox=dict(facecolor="black", alpha=0.3, pad=1))
            plt.title(f"Field t={t_}")
            plt.subplot(2, T, T+t_+1)
            plt.imshow(mask_hw_t[..., t_], cmap='gray', vmin=0, vmax=1)
            plt.title(f"Mask t={t_}")
            plt.axis('off')
        plt.suptitle(f"Sample {i} (Output_1)")
        plt.tight_layout()
        save_path = os.path.join(out_dir, f"sample_{idx_num}.png")
        plt.savefig(save_path, dpi=120, bbox_inches='tight')
        plt.close()

def visualize_output_2(X, Y, Pred, Sinfo, out_dir="outputs/output_2", count=10):
    """原始数据+GT+预测Mask(含Dice)."""
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)
    indices = np.random.choice(len(X), size=min(count, len(X)), replace=False)
    for idx_num, i in enumerate(indices):
        field_hw_t = X[i]
        mask_hw_t  = Y[i]
        pred_hw_t  = Pred[i]
        sources    = Sinfo[i]
        H, W, T = field_hw_t.shape
        dice_val = dice_coef_np(mask_hw_t, pred_hw_t)
        plt.figure(figsize=(3*T, 9))
        for t_ in range(T):
            plt.subplot(3, T, t_+1)
            fm_ = field_hw_t[..., t_]
            plot_sources_on_field(plt.gca(), fm_, sources)
            plt.title(f"Field t={t_}")
            plt.subplot(3, T, T+t_+1)
            plt.imshow(mask_hw_t[..., t_], cmap='gray', vmin=0, vmax=1)
            plt.title(f"GT Mask t={t_}")
            plt.axis('off')
            plt.subplot(3, T, 2*T+t_+1)
            plt.imshow(pred_hw_t[..., t_], cmap='gray', vmin=0, vmax=1)
            plt.title(f"Pred t={t_}")
            plt.axis('off')
        plt.suptitle(f"Sample {i} (Output_2) - Dice={dice_val:.3f}")
        plt.tight_layout()
        save_path = os.path.join(out_dir, f"sample_{idx_num}.png")
        plt.savefig(save_path, dpi=120, bbox_inches='tight')
        plt.close()

def visualize_output_3(X, Y, Sinfo, vit_model, out_dir="outputs/output_3", count=10):
    """
    分两行T列：第一行显示原始数据及真源标记，
    第二行显示同一时刻ViT预测的分类与位置回归结果，同时显示预测坐标。
    """
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)
    indices = np.random.choice(len(X), size=min(count, len(X)), replace=False)
    type_map = {0:"dipole", 1:"line", 2:"quad"}
    for idx_num, sample_idx in enumerate(indices):
        field_hw_t = X[sample_idx]  # (H,W,T)
        mask_hw_t = Y[sample_idx]   # (H,W,T)
        sources = Sinfo[sample_idx]
        H, W, T = field_hw_t.shape
        plt.figure(figsize=(3*T, 6))
        for t_ in range(T):
            # 第一行：原始数据 + 真源标记
            plt.subplot(2, T, t_+1)
            frame_t = field_hw_t[..., t_]
            vmn, vmx = np.percentile(frame_t, [5,95])
            plt.imshow(frame_t, cmap='turbo', vmin=vmn, vmax=vmx)
            plt.title(f"Field t={t_}")
            plt.axis('off')
            for s in sources:
                tname = s[0]
                x0 = s[2]
                y0 = s[3]
                plt.plot(y0, x0, 'rx', ms=4, mew=1.5)
                plt.text(y0+1, x0+1, f"{tname}\n({x0:.1f},{y0:.1f})",
                         color='white', fontsize=6,
                         bbox=dict(facecolor='black', alpha=0.3, pad=1))
            # 第二行：ViT分类与位置回归结果
            plt.subplot(2, T, T+t_+1)
            plt.imshow(frame_t, cmap='turbo', vmin=vmn, vmax=vmx)
            plt.title(f"Cls+Reg t={t_}")
            plt.axis('off')
            mask_t = mask_hw_t[..., t_].astype(np.uint8)
            num_l, _, stats, centroids = cv2.connectedComponentsWithStats(mask_t, connectivity=8)
            for lb in range(1, num_l):
                x2 = stats[lb, cv2.CC_STAT_LEFT]
                y2 = stats[lb, cv2.CC_STAT_TOP]
                w2 = stats[lb, cv2.CC_STAT_WIDTH]
                h2 = stats[lb, cv2.CC_STAT_HEIGHT]
                if w2 < 2 or h2 < 2:
                    continue
                sub_img = field_hw_t[y2:y2+h2, x2:x2+w2, :]
                sub_img_res = np.zeros((96, 96, T), dtype=np.float32)
                for chan in range(T):
                    tmp = cv2.resize(sub_img[..., chan], (96, 96))
                    mm, ss = tmp.mean(), tmp.std()+1e-6
                    tmp = (tmp - mm)/ss
                    sub_img_res[..., chan] = tmp
                sub_img_res = np.expand_dims(sub_img_res, axis=0)
                pred_cls_logits, pred_pos = vit_model.predict(sub_img_res, verbose=0)
                pred_cls_id = np.argmax(pred_cls_logits[0])
                pred_cls_str = type_map.get(pred_cls_id, "Unknown")
                px, py = pred_pos[0]
                pred_x0 = y2 + px*h2
                pred_y0 = x2 + py*w2
                rect = plt.Rectangle((x2, y2), w2, h2,
                                     edgecolor='lime',
                                     facecolor='none',
                                     linewidth=1.5)
                plt.gca().add_patch(rect)
                plt.plot(pred_y0, pred_x0, 'go', ms=4)
                plt.text(x2, y2-4, f"{pred_cls_str}",
                         color='lime', fontsize=6,
                         bbox=dict(facecolor='black', alpha=0.3, pad=1))
                plt.text(x2, y2-12, f"({pred_x0:.1f}, {pred_y0:.1f})",
                         color='lime', fontsize=6,
                         bbox=dict(facecolor='black', alpha=0.3, pad=1))
        plt.suptitle(f"Sample {sample_idx} (Output_3)")
        plt.tight_layout()
        out_file = os.path.join(out_dir, f"sample_{idx_num}.png")
        plt.savefig(out_file, dpi=120, bbox_inches='tight')
        plt.close()


###############################################################################
# 四、测试流程：对不同overlap水平的数据进行评估
###############################################################################
def measure_cgan_metrics(Y_true, Y_pred):
    """
    计算分割指标: IoU & Dice
    """
    iou_val = compute_iou(Y_true, Y_pred)
    dice_val= dice_coef_np(Y_true, Y_pred)
    return float(iou_val), float(dice_val)

def measure_vit_metrics(X, Y, Sinfo, vit_model):
    """
    计算分类准确率 + 位置回归RMSE.
    思路：
      - 先对 union mask 做 connectedComponents,
      - 对每个真源在 union mask 中找最近的连通域，
      - 提取子图 -> vit_model预测，
      - 比对分类正确否，并计算位置误差.
    """
    type_correct = 0
    type_total   = 0
    sum_sq_error = 0.0
    pos_count    = 0

    type_map = {0:"dipole", 1:"line", 2:"quad"}

    for i in range(len(X)):
        # 合并所有帧掩码 => union_mask
        union_mask = np.max(Y[i], axis=-1).astype(np.uint8)
        num_l, _, stats, centroids = cv2.connectedComponentsWithStats(union_mask, connectivity=8)

        # 逐源
        for src in Sinfo[i]:
            stype_id = src[1]  # 0/1/2
            x0, y0   = src[2], src[3]

            # 找与(x0,y0)最近的连通域 lb
            best_lb, best_d = None, 1e9
            for lb in range(1, num_l):
                cy, cx = centroids[lb]  # 注意cv2返回(cx, cy)，其中 x为列坐标
                dd = (cx - x0)**2 + (cy - y0)**2
                if dd < best_d:
                    best_d = dd
                    best_lb = lb
            if best_lb is None:
                continue
            x2 = stats[best_lb, cv2.CC_STAT_LEFT]
            y2 = stats[best_lb, cv2.CC_STAT_TOP]
            w2 = stats[best_lb, cv2.CC_STAT_WIDTH]
            h2 = stats[best_lb, cv2.CC_STAT_HEIGHT]
            if w2<2 or h2<2:
                continue

            # 提取子图
            sub_img = X[i, y2:y2+h2, x2:x2+w2, :]  # shape (h2,w2,T)
            sub_res = np.zeros((96, 96, sub_img.shape[2]), dtype=np.float32)
            for t_ in range(sub_img.shape[2]):
                tmp = cv2.resize(sub_img[..., t_], (96, 96))
                mm, ss = tmp.mean(), tmp.std() + 1e-6
                tmp = (tmp - mm)/ss
                sub_res[..., t_] = tmp
            sub_res = np.expand_dims(sub_res, axis=0) # (1,96,96,T)

            pred_cls_logits, pred_pos = vit_model.predict(sub_res, verbose=0)
            pred_cls_id = np.argmax(pred_cls_logits[0])
            # 分类正确吗
            if pred_cls_id==stype_id:
                type_correct += 1
            type_total += 1

            # 位置误差
            px, py = pred_pos[0]
            pred_x = y2 + px*h2
            pred_y = x2 + py*w2
            sq_err = (pred_x - x0)**2 + (pred_y - y0)**2
            sum_sq_error += sq_err
            pos_count += 1

    if type_total==0:
        cls_acc = 1.0
    else:
        cls_acc = type_correct / type_total

    if pos_count==0:
        rmse = 0.0
    else:
        rmse = math.sqrt(sum_sq_error / pos_count)

    return cls_acc, rmse

###############################################################################
# 五、主函数：对不同overlap跑测试并保存结果
###############################################################################
def main():
    # 1) 加载已训练好的 Generator (cGAN)
    gen_path = "outputs/attention_unet_gen_dynamic_v2.keras"
    if not os.path.exists(gen_path):
        raise FileNotFoundError(f"找不到预训练生成器文件: {gen_path}")
    # 先构建一个同结构的模型，然后加载权重
    generator = build_attention_unet(input_shape=(128,128,5), out_channels=5)
    generator.load_weights(gen_path)

    # 2) 加载已训练好的 ViT
    vit_path = "outputs/vit_dynamic_v2.keras"
    if not os.path.exists(vit_path):
        raise FileNotFoundError(f"找不到预训练ViT文件: {vit_path}")
    vit_model = build_simple_vit(
        input_shape=(96,96,5),
        patch_size=16, num_heads=8, embed_dim=256, ff_dim=512, transformer_layers=6
    )
    # 注意要显式传入自定义层
    custom_objs = {"Patches": Patches, "PatchEncoder": PatchEncoder}
    vit_model.load_weights(vit_path)

    # 3) 分别生成 low / medium / high 三种重叠度的数据集
    test_levels = ["very_low", "low", "medium", "high", "very_high"]
    results_dict = {}

    for lvl in test_levels:
        print(f"[INFO] Generating test dataset for overlap='{lvl}' ...")
        X_test, Y_test, Sinfo_test = create_dataset_for_overlap_test(
            num_samples=10000,  # 可自行调整
            grid_size=128,
            T=5,
            overlap_level=lvl
        )
        print(f"[INFO] Overlap='{lvl}', dataset size = {len(X_test)}")

        # 用已训练好的 generator 预测分割
        preds_test = generator.predict(X_test)
        # 计算分割指标
        iou_val = compute_iou(Y_test, preds_test)
        dice_val= dice_coef_np(Y_test, preds_test)

        # 计算分类与定位指标
        cls_acc, loc_rmse = measure_vit_metrics(X_test, Y_test, Sinfo_test, vit_model)

        results_dict[lvl] = {
            "IoU": float(iou_val),
            "Dice": float(dice_val),
            "ClassificationAcc": float(cls_acc),
            "LocationRMSE": float(loc_rmse)
        }

        # 可选：做可视化
        outdir_1 = f"outputs/{lvl}/output_1"
        outdir_2 = f"outputs/{lvl}/output_2"
        outdir_3 = f"outputs/{lvl}/output_3"
        visualize_output_1(X_test, Y_test, Sinfo_test, out_dir=outdir_1, count=5)
        visualize_output_2(X_test, Y_test, preds_test, Sinfo_test, out_dir=outdir_2, count=5)
        visualize_output_3(X_test, Y_test, Sinfo_test, vit_model, out_dir=outdir_3, count=5)

    # 4) 将结果保存到JSON
    out_json = "outputs/experiment_3_results.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(results_dict, f, indent=2, ensure_ascii=False)
    print(f"[INFO] Done. Results saved in {out_json}")
    print("Results:", results_dict)

if __name__ == "__main__":
    main()
