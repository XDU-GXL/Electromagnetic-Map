#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import math
import json
import random
import numpy as np
import cv2

import cupy as cp
import cupyx.scipy.ndimage as ndi

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.losses import BinaryCrossentropy
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras import backend as K
from sklearn.metrics import confusion_matrix

###############################################################################
# 注：以下函数与原脚本相同，不再贴出：
# 1) compute_iou
# 2) dipole_field_2d_vector, line_current_field_2d_vector, quadrupole_field_2d_vector
# 3) simulate_magnetic_distortion_2d_dynamic( )  —— 这里若要在Experiment C中增加“随机旋转”，
#    实际要在 create_dataset_dynamic 时处理。见下文 do_augment 的改动。
# 4) combined_bce_dice_loss, focal_bce_loss, dice_coef, dice_loss
# 5) build_patchgan_discriminator( )
# 6) plot_sources_on_field( ), visualize_output_1( ), visualize_output_2( ), visualize_output_3( )
###############################################################################
###############################################################################
# 辅助函数：计算IoU（这里作为IOT指标）
###############################################################################
def compute_iou(y_true, y_pred):
    y_true_bin = (y_true > 0.5).astype(np.float32)
    y_pred_bin = (y_pred > 0.5).astype(np.float32)
    intersection = np.sum(y_true_bin * y_pred_bin)
    union = np.sum(y_true_bin) + np.sum(y_pred_bin) - intersection
    return (intersection + 1e-6) / (union + 1e-6)

###############################################################################
# 1. 数据生成：时间变化的 2D 磁场模拟 (已向量化)
###############################################################################

def dipole_field_2d_vector(grid_size, x0, y0, moment, inc_deg, dec_deg):
    """
    使用 cupy 向量化计算偶极子场。
    Bz ~ (M·r)/r^3
    """
    inc = cp.radians(inc_deg)
    dec = cp.radians(dec_deg)
    # 计算 Mx, My
    Mx = moment * cp.cos(inc) * cp.cos(dec)
    My = moment * cp.cos(inc) * cp.sin(dec)

    # 建立网格坐标 (ix, iy)
    ix = cp.arange(grid_size, dtype=cp.float32)
    iy = cp.arange(grid_size, dtype=cp.float32)
    rx, ry = cp.meshgrid(ix, iy, indexing='ij')  # shape=(grid_size,grid_size)

    # 相对位移
    rx = rx - x0
    ry = ry - y0

    r_sq = rx*rx + ry*ry + 1e-12
    r_3  = r_sq**1.5
    dotMr= Mx*rx + My*ry
    return dotMr / r_3  # shape=(grid_size,grid_size)

def line_current_field_2d_vector(grid_size, x0, y0, current):
    """
    使用 cupy 向量化计算线电流场 (简化)：
    Bz ~ current / r
    """
    ix = cp.arange(grid_size, dtype=cp.float32)
    iy = cp.arange(grid_size, dtype=cp.float32)
    rx, ry = cp.meshgrid(ix, iy, indexing='ij')
    rx = rx - x0
    ry = ry - y0
    rr = cp.sqrt(rx*rx + ry*ry + 1e-12)
    return current / rr

def quadrupole_field_2d_vector(grid_size, x0, y0, strength):
    """
    使用 cupy 向量化计算四极子场（简化模型）:
    Bz ~ (2*ry^2 - r^2)/r^3
    """
    ix = cp.arange(grid_size, dtype=cp.float32)
    iy = cp.arange(grid_size, dtype=cp.float32)
    rx, ry = cp.meshgrid(ix, iy, indexing='ij')
    rx = rx - x0
    ry = ry - y0
    r_sq= rx*rx + ry*ry + 1e-12
    r_3 = r_sq**1.5
    return strength*((2.*ry*ry - r_sq)/r_3)


def simulate_magnetic_distortion_2d_dynamic(
    grid_size=128,
    max_sources=10,
    background_strength=0.58,
    threshold_ratio=0.04,
    T=5
):
    """
    生成 T 帧的2D磁场 + (H,W,T)的mask（逐帧阈值），已向量化加速。
    返回:
      field_3d: (T,H,W)
      mask_3d:  (T,H,W)
      src_list: 源信息 (类型, stype, x0, y0, 其他参数)

    改动：
    - 不再在背景中添加小幅随机扰动，而是先保持平坦背景，
    - 生成掩码后，再对整体加入高斯 / 拉普拉斯 / 混合噪声 (幅度0.005~0.05)。
    """

    # 背景设为固定平坦
    base_bg = background_strength * cp.ones((grid_size, grid_size), dtype=cp.float32)

    # 随机生成若干源
    n_sources= random.randint(1, max_sources)
    sources_params = []
    for _ in range(n_sources):
        stype = random.randint(0,2)  # 0=dipole,1=line,2=quad
        x0 = random.uniform(0, grid_size)
        y0 = random.uniform(0, grid_size)

        if stype == 0:  # dipole
            moment_base = random.uniform(0.06, 0.20)
            inc = random.uniform(-30, 30)
            dec = random.uniform(0, 360)
            freq = random.uniform(0.5, 2.0)
            phase= random.uniform(0, 2*math.pi)
            amps = []
            for t_ in range(T):
                scale = 0.5 + 0.5*math.sin(freq*(t_ + phase))
                amps.append(scale * moment_base)
            sources_params.append(("dipole", stype, x0, y0, inc, dec, amps))

        elif stype == 1:  # line
            length = random.uniform(5, 20)   # length 未在公式里使用,保留仅作信息
            current_base= random.uniform(0.06, 0.20)
            freq = random.uniform(0.5, 2.0)
            phase= random.uniform(0, 2*math.pi)
            amps = []
            for t_ in range(T):
                scale = 0.5 + 0.5*math.cos(freq*(t_ + phase))
                amps.append(scale * current_base)
            sources_params.append(("line", stype, x0, y0, length, amps))

        else:  # quad
            strength_base = random.uniform(0.06, 0.20)
            freq = random.uniform(0.5, 2.0)
            phase= random.uniform(0, 2*math.pi)
            amps = []
            for t_ in range(T):
                scale = 0.5 + 0.5*math.sin(freq*(t_ + phase))
                amps.append(scale * strength_base)
            sources_params.append(("quad", stype, x0, y0, amps))

    # 初始化 T 帧的场：每帧先是相同的 base_bg
    frames_field = cp.tile(base_bg[None, ...], (T, 1, 1))  # shape=(T,H,W)

    # 依次将各源对每一帧的贡献叠加
    for sp in sources_params:
        if sp[0] == 'dipole':
            # sp=( 'dipole', 0, x0, y0, inc, dec, [amps...] )
            x0   = sp[2]
            y0   = sp[3]
            inc  = sp[4]
            dec  = sp[5]
            amp_list = sp[6]
            for t_ in range(T):
                field_add = dipole_field_2d_vector(grid_size, x0, y0, amp_list[t_], inc, dec)
                frames_field[t_] += field_add
        elif sp[0] == 'line':
            # sp=( 'line', 1, x0, y0, length, [amps...] )
            x0   = sp[2]
            y0   = sp[3]
            amp_list = sp[5]
            for t_ in range(T):
                field_add = line_current_field_2d_vector(grid_size, x0, y0, amp_list[t_])
                frames_field[t_] += field_add
        else:
            # sp=( 'quad', 2, x0, y0, [amps...] )
            x0   = sp[2]
            y0   = sp[3]
            amp_list = sp[4]
            for t_ in range(T):
                field_add = quadrupole_field_2d_vector(grid_size, x0, y0, amp_list[t_])
                frames_field[t_] += field_add

    # 先在无噪声情况下生成 mask
    mask_3d_cp  = cp.zeros_like(frames_field, dtype=cp.uint8)
    thr_value   = threshold_ratio * background_strength
    for t_ in range(T):
        diff_t = cp.abs(frames_field[t_] - background_strength)
        mask_3d_cp[t_] = (diff_t >= thr_value).astype(cp.uint8)

    # 然后对整体添加高斯 / 拉普拉斯 / 混合噪声，幅度在 [0.005, 0.05]
    noise_amplitude = random.uniform(0.005, 0.03)
    noise_type = random.choice(["gaussian", "laplacian", "mixed"])
    for t_ in range(T):
        if noise_type == "gaussian":
            noise_cp = noise_amplitude * cp.random.randn(grid_size, grid_size).astype(cp.float32)
        elif noise_type == "laplacian":
            noise_cp = noise_amplitude * cp.random.laplace(size=(grid_size, grid_size)).astype(cp.float32)
        else:  # "mixed"
            noise_cp = noise_amplitude * (
                0.5 * cp.random.randn(grid_size, grid_size).astype(cp.float32) +
                0.5 * cp.random.laplace(size=(grid_size, grid_size)).astype(cp.float32)
            )
        frames_field[t_] += noise_cp

    # 转回CPU
    field_3d = frames_field.get().astype(np.float32)  # (T,H,W)
    mask_3d  = mask_3d_cp.get().astype(np.uint8)      # (T,H,W)

    # 简化记录源信息: 仅存平均幅度 / etc
    src_list = []
    for sp in sources_params:
        if sp[0] == 'dipole':
            avg_m = sum(sp[6]) / len(sp[6])
            src_list.append((sp[0], sp[1], sp[2], sp[3], avg_m, sp[4], sp[5]))
        elif sp[0] == 'line':
            avg_c = sum(sp[5]) / len(sp[5])
            src_list.append((sp[0], sp[1], sp[2], sp[3], sp[4], avg_c))
        else:
            avg_s = sum(sp[4]) / len(sp[4])
            src_list.append((sp[0], sp[1], sp[2], sp[3], avg_s))

    return field_3d, mask_3d, src_list




def dice_coef(y_true, y_pred, smooth=1e-6):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    inter = K.sum(y_true_f * y_pred_f)
    den   = K.sum(y_true_f) + K.sum(y_pred_f)
    return (2.*inter+smooth)/(den+smooth)

def dice_loss(y_true, y_pred):
    return 1.0 - dice_coef(y_true, y_pred)

def combined_bce_dice_loss(y_true, y_pred):
    bce = tf.keras.losses.binary_crossentropy(y_true, y_pred)
    bce = tf.reduce_mean(bce)
    return bce + dice_loss(y_true, y_pred)

def focal_bce_loss(y_true, y_pred, gamma=2.0):
    """
    备选：Focal Loss(基于binary cross-entropy)
    """
    bce = tf.keras.losses.binary_crossentropy(y_true, y_pred)
    pt  = tf.exp(-bce)
    focal = (1-pt)**gamma * bce
    return tf.reduce_mean(focal)

def build_patchgan_discriminator(input_shape=(128,128,2)):
    inp = layers.Input(input_shape)
    x   = layers.Conv2D(64, 4, strides=2, padding='same')(inp)
    x   = layers.LeakyReLU(0.2)(x)
    x   = layers.Conv2D(128, 4, strides=2, padding='same')(x)
    x   = layers.LeakyReLU(0.2)(x)
    x   = layers.Conv2D(256, 4, strides=2, padding='same')(x)
    x   = layers.LeakyReLU(0.2)(x)
    x   = layers.Flatten()(x)
    x   = layers.Dense(1)(x)
    return models.Model(inp, x, name='PatchDiscriminator')


###############################################################################
# 辅助函数：带返回值的绘图函数（热力图+标记）
###############################################################################
def plot_sources_on_field(ax, field2d, sources, add_colorbar=True):
    """
    在ax上绘制field2d，并在其上用红叉加文本标记sources。
    返回图像handle，以便后续添加colorbar。
    vmin,vmax基于field2d的[5%,95%]分位数自动计算。
    """
    vmin, vmax = np.percentile(field2d, [5, 95])
    img_handle = ax.imshow(field2d, cmap='turbo', vmin=vmin, vmax=vmax)
    # 标记源位置
    for s in sources:
        tname = s[0]
        x0 = s[2]
        y0 = s[3]
        ax.plot(y0, x0, 'rx', ms=5, mew=1.5)
        ax.text(y0 + 2, x0 + 2, f"{tname}\n({x0:.1f},{y0:.1f})",
                color='white', fontsize=6,
                bbox=dict(facecolor='black', alpha=0.3, pad=1))

    ax.axis('off')
    return img_handle


###############################################################################
# 1. 可视化函数：输出1
###############################################################################
def visualize_output_1(X, Y, Sinfo, out_dir="outputs/output_1", count=10):
    """
    原始数据(标注源信息) + GT mask，并在原始数据上标记信噪比(SNR)，
    其中标记方式与“输出一”保持一致，并添加热力条与SVG保存。
    """
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    indices = np.random.choice(len(X), size=min(count, len(X)), replace=False)
    for idx_num, i in enumerate(indices):
        field_hw_t = X[i]  # (H,W,T)
        mask_hw_t  = Y[i]  # (H,W,T)
        sources    = Sinfo[i]
        H, W, T = field_hw_t.shape

        plt.figure(figsize=(3*T, 6))
        for t_ in range(T):
            # 上面一行：显示原始数据 + SNR
            plt.subplot(2, T, t_+1)
            fm_ = field_hw_t[..., t_]
            im_handle = plot_sources_on_field(plt.gca(), fm_, sources)

            # 计算SNR：均值 / 标准差
            snr = np.mean(fm_) / (np.std(fm_) + 1e-6)
            plt.text(5, 15, f"SNR: {snr:.2f}", color="yellow", fontsize=6,
                     bbox=dict(facecolor="black", alpha=0.3, pad=1))
            plt.title(f"Field t={t_}")

            # 添加热力条（只对原始数据）
            plt.colorbar(im_handle, ax=plt.gca(), fraction=0.046, pad=0.04)

            # 下面一行：显示GT mask
            plt.subplot(2, T, T+t_+1)
            plt.imshow(mask_hw_t[..., t_], cmap='gray', vmin=0, vmax=1)
            plt.title(f"Mask t={t_}")
            plt.axis('off')

        plt.suptitle(f"Sample {i} (Output_1)")
        plt.tight_layout()

        # 保存为SVG并设置较高dpi
        save_path = os.path.join(out_dir, f"sample_{idx_num}.svg")
        plt.savefig(save_path, format='svg', dpi=600, bbox_inches='tight')
        plt.close()


###############################################################################
# 2. 可视化函数：输出2
###############################################################################
def visualize_output_2(X, Y, Pred, Sinfo, out_dir="outputs/output_2", count=10):
    """
    原始数据+GT+预测Mask(含Dice)，标记方式与输出一统一，添加热力条与SVG保存。
    """
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    indices = np.random.choice(len(X), size=min(count, len(X)), replace=False)
    for idx_num, i in enumerate(indices):
        field_hw_t = X[i]   # (H,W,T)
        mask_hw_t  = Y[i]   # (H,W,T)
        pred_hw_t  = Pred[i]
        sources    = Sinfo[i]
        H, W, T = field_hw_t.shape

        # 计算全帧Dice
        gt_bin = (mask_hw_t > 0.5).astype(np.float32)
        pd_bin = (pred_hw_t > 0.5).astype(np.float32)
        inter = np.sum(gt_bin * pd_bin)
        den = np.sum(gt_bin) + np.sum(pd_bin)
        dice_val = (2. * inter + 1e-6) / (den + 1e-6)

        plt.figure(figsize=(3*T, 9))
        for t_ in range(T):
            # 第一行：原始数据
            plt.subplot(3, T, t_+1)
            fm_ = field_hw_t[..., t_]
            im_handle = plot_sources_on_field(plt.gca(), fm_, sources)
            plt.title(f"Field t={t_}")
            plt.colorbar(im_handle, ax=plt.gca(), fraction=0.046, pad=0.04)

            # 第二行：GT mask
            plt.subplot(3, T, T+t_+1)
            plt.imshow(mask_hw_t[..., t_], cmap='gray', vmin=0, vmax=1)
            plt.title(f"GT Mask t={t_}")
            plt.axis('off')

            # 第三行：预测Mask
            plt.subplot(3, T, 2*T+t_+1)
            plt.imshow(pred_hw_t[..., t_], cmap='gray', vmin=0, vmax=1)
            plt.title(f"Pred t={t_}")
            plt.axis('off')

        plt.suptitle(f"Sample {i} (Output_2) - Dice={dice_val:.3f}")
        plt.tight_layout()

        save_path = os.path.join(out_dir, f"sample_{idx_num}.svg")
        plt.savefig(save_path, format='svg', dpi=600, bbox_inches='tight')
        plt.close()


###############################################################################
# 3. 可视化函数：输出3
###############################################################################
def visualize_output_3(X, Y, Sinfo, vit_model, out_dir="outputs/output_3", count=10):
    """
    分两行T列：第一行显示原始数据(含真源标记)，
    第二行显示同一时刻的ViT预测(附分类+位置回归结果)。
    标记方式与输出一保持一致，添加热力条并保存为SVG。
    """
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    indices = np.random.choice(len(X), size=min(count, len(X)), replace=False)
    type_map = {0: "dipole", 1: "line", 2: "quad"}

    for idx_num, sample_idx in enumerate(indices):
        field_hw_t = X[sample_idx]  # (H,W,T)
        mask_hw_t  = Y[sample_idx]  # (H,W,T)
        sources    = Sinfo[sample_idx]
        H, W, T = field_hw_t.shape

        plt.figure(figsize=(3*T, 6))
        for t_ in range(T):
            # ========== 第一行：原始数据 + 真源标记 ==========
            plt.subplot(2, T, t_+1)
            fm_ = field_hw_t[..., t_]
            # 用plot_sources_on_field统一画法（红叉+白框）
            im_handle = plot_sources_on_field(plt.gca(), fm_, sources)
            plt.title(f"Field t={t_}")
            plt.colorbar(im_handle, ax=plt.gca(), fraction=0.046, pad=0.04)

            # ========== 第二行：ViT分类与位置回归结果 ==========
            plt.subplot(2, T, T + t_ + 1)
            # 先画原始数据，但不标记真源
            im_handle2 = plt.imshow(fm_, cmap='turbo',
                                    vmin=np.percentile(fm_, 5),
                                    vmax=np.percentile(fm_, 95))
            plt.title(f"Cls+Reg t={t_}")
            plt.axis('off')
            plt.colorbar(im_handle2, ax=plt.gca(), fraction=0.046, pad=0.04)

            # 在mask上找连通域，并用ViT做预测
            mask_t = mask_hw_t[..., t_].astype(np.uint8)
            num_l, labels, stats, centroids = cv2.connectedComponentsWithStats(mask_t, connectivity=8)

            for lb in range(1, num_l):
                x2 = stats[lb, cv2.CC_STAT_LEFT]
                y2 = stats[lb, cv2.CC_STAT_TOP]
                w2 = stats[lb, cv2.CC_STAT_WIDTH]
                h2 = stats[lb, cv2.CC_STAT_HEIGHT]
                if w2 < 2 or h2 < 2:
                    continue

                # 提取子图并Resize->(96,96)
                sub_img = field_hw_t[y2:y2+h2, x2:x2+w2, :]
                sub_img_res = np.zeros((96, 96, T), dtype=np.float32)
                for chan in range(T):
                    tmp = cv2.resize(sub_img[..., chan], (96, 96))
                    mm, ss = tmp.mean(), tmp.std() + 1e-6
                    tmp = (tmp - mm) / ss
                    sub_img_res[..., chan] = tmp
                sub_img_res = np.expand_dims(sub_img_res, axis=0)

                # ViT预测
                pred_cls_logits, pred_pos = vit_model.predict(sub_img_res, verbose=0)
                pred_cls_id = np.argmax(pred_cls_logits[0])
                pred_cls_str = type_map.get(pred_cls_id, "Unknown")

                # 解析回归坐标
                px, py = pred_pos[0]
                pred_x0 = y2 + px*h2
                pred_y0 = x2 + py*w2

                # 以“输出一”的方式在图上画预测点(红叉+白字)
                plt.plot(pred_y0, pred_x0, 'rx', ms=5, mew=1.5)
                plt.text(pred_y0 + 2, pred_x0 + 2,
                         f"{pred_cls_str}\n({pred_x0:.1f},{pred_y0:.1f})",
                         color='white', fontsize=6,
                         bbox=dict(facecolor='black', alpha=0.3, pad=1))

        plt.suptitle(f"Sample {sample_idx} (Output_3)")
        plt.tight_layout()

        out_file = os.path.join(out_dir, f"sample_{idx_num}.svg")
        plt.savefig(out_file, format='svg', dpi=600, bbox_inches='tight')
        plt.close()



###############################################################################
# 1. 数据生成（在 do_augment=True 时增加随机旋转）
###############################################################################
def create_dataset_dynamic(num_samples=100, grid_size=128, T=5, do_augment=False):
    """
    与原版相比，仅在 do_augment=True 时，多加一步随机旋转:
      - 旋转角度 alpha ∈ [-15, 15]
      - 需要同步更新源信息 (x0, y0)
    其他逻辑与原版相同，不再赘述。
    """

    X_list, Y_list, info_list = [], [], []
    for _ in range(num_samples):
        f3d, m3d, srcs = simulate_magnetic_distortion_2d_dynamic(
            grid_size=grid_size,
            max_sources=10,
            background_strength=0.58,
            threshold_ratio=0.04,
            T=T
        )
        # (T,H,W) -> (H,W,T)
        f3d_hw = np.transpose(f3d, (1,2,0))
        m3d_hw = np.transpose(m3d, (1,2,0))

        # 简单随机数据增强
        if do_augment:
            # 水平/垂直翻转（原有）
            if random.random() < 0.5:
                f3d_hw = f3d_hw[:, ::-1, :]
                m3d_hw = m3d_hw[:, ::-1, :]
                new_srcs = []
                for s in srcs:
                    new_y = grid_size - s[3]
                    if s[0] == "dipole":
                        new_src = (s[0], s[1], s[2], new_y, s[4], s[5], s[6])
                    elif s[0] == "line":
                        new_src = (s[0], s[1], s[2], new_y, s[4], s[5])
                    else:
                        new_src = (s[0], s[1], s[2], new_y, s[4])
                    new_srcs.append(new_src)
                srcs = new_srcs
            if random.random() < 0.5:
                f3d_hw = f3d_hw[::-1, :, :]
                m3d_hw = m3d_hw[::-1, :, :]
                new_srcs = []
                for s in srcs:
                    new_x = grid_size - s[2]
                    if s[0] == "dipole":
                        new_src = (s[0], s[1], new_x, s[3], s[4], s[5], s[6])
                    elif s[0] == "line":
                        new_src = (s[0], s[1], new_x, s[3], s[4], s[5])
                    else:
                        new_src = (s[0], s[1], new_x, s[3], s[4])
                    new_srcs.append(new_src)
                srcs = new_srcs

            # === 额外增加随机旋转（Experiment C） ===
            if random.random() < 0.5:  # 50%概率
                alpha_deg = random.uniform(-15, 15)
                alpha_rad = alpha_deg * math.pi / 180.0

                # 1) 旋转图像
                M = cv2.getRotationMatrix2D((grid_size/2, grid_size/2), alpha_deg, 1.0)
                # 逐帧旋转
                for t_ in range(T):
                    # 因为 f3d_hw[..., t_] 和 m3d_hw[..., t_] 都是 HxW
                    # 分别做仿射变换
                    tmp_f = cv2.warpAffine(f3d_hw[..., t_], M, (grid_size, grid_size),
                                           flags=cv2.INTER_LINEAR,
                                           borderMode=cv2.BORDER_CONSTANT, borderValue=0)
                    tmp_m = cv2.warpAffine(m3d_hw[..., t_], M, (grid_size, grid_size),
                                           flags=cv2.INTER_NEAREST,
                                           borderMode=cv2.BORDER_CONSTANT, borderValue=0)
                    f3d_hw[..., t_] = tmp_f
                    m3d_hw[..., t_] = tmp_m

                # 2) 同步更新源坐标
                new_srcs = []
                cx, cy = grid_size/2, grid_size/2
                for s in srcs:
                    # s=(type, stype, x0, y0, ...)
                    x0, y0 = s[2], s[3]
                    # 旋转前先移到中心坐标系
                    x0c, y0c = x0 - cx, y0 - cy
                    # 在中心坐标系下旋转
                    x_rot = x0c*math.cos(alpha_rad) - y0c*math.sin(alpha_rad)
                    y_rot = x0c*math.sin(alpha_rad) + y0c*math.cos(alpha_rad)
                    # 再移回图像坐标
                    xr = x_rot + cx
                    yr = y_rot + cy
                    if s[0] == "dipole":
                        new_s = (s[0], s[1], xr, yr, s[4], s[5], s[6])
                    elif s[0] == "line":
                        new_s = (s[0], s[1], xr, yr, s[4], s[5])
                    else:
                        new_s = (s[0], s[1], xr, yr, s[4])
                    new_srcs.append(new_s)
                srcs = new_srcs

        X_list.append(f3d_hw)
        Y_list.append(m3d_hw)
        info_list.append(srcs)

    X = np.array(X_list, dtype=np.float32)
    Y = np.array(Y_list, dtype=np.float32)
    return X, Y, info_list


###############################################################################
# 2. 替换用的不同生成器结构（Experiment A / B）
###############################################################################
def build_resunet_generator(input_shape=(128,128,5), out_channels=5):
    """
    Experiment A: 在U-Net的每个Down/Up阶段用残差Block替换原双卷积。
    """
    def res_block(x, filters):
        # Conv + BN + ReLU + Conv + BN + skip
        shortcut = x
        x = layers.Conv2D(filters, 3, padding='same')(x)
        x = layers.BatchNormalization()(x)
        x = layers.Activation('relu')(x)
        x = layers.Conv2D(filters, 3, padding='same')(x)
        x = layers.BatchNormalization()(x)
        # skip
        if shortcut.shape[-1] != filters:
            # 用1x1 conv匹配通道
            shortcut = layers.Conv2D(filters, 1, padding='same')(shortcut)
        x = layers.add([x, shortcut])
        x = layers.Activation('relu')(x)
        return x

    inp = layers.Input(input_shape)
    # down1
    c1 = res_block(inp, 64)
    p1 = layers.MaxPooling2D(2)(c1)

    # down2
    c2 = res_block(p1, 128)
    p2 = layers.MaxPooling2D(2)(c2)

    # down3
    c3 = res_block(p2, 256)
    p3 = layers.MaxPooling2D(2)(c3)

    # bottom
    c4 = res_block(p3, 512)

    # up3
    u3 = layers.Conv2DTranspose(256, 2, strides=2, padding='same')(c4)
    u3 = layers.concatenate([u3, c3], axis=-1)
    c5 = res_block(u3, 256)

    # up2
    u2 = layers.Conv2DTranspose(128, 2, strides=2, padding='same')(c5)
    u2 = layers.concatenate([u2, c2], axis=-1)
    c6 = res_block(u2, 128)

    # up1
    u1 = layers.Conv2DTranspose(64, 2, strides=2, padding='same')(c6)
    u1 = layers.concatenate([u1, c1], axis=-1)
    c7 = res_block(u1, 64)

    outp = layers.Conv2D(out_channels, 1, activation='sigmoid')(c7)
    return models.Model(inp, outp, name='ResUNet')


def build_multiscale_attention_unet(input_shape=(128,128,5), out_channels=5):
    """
    修正后的多尺度注意力UNet示例，保证多尺度拼接时空间形状相同。
    """
    def conv_block(x, filters):
        x = layers.Conv2D(filters, 3, padding='same', activation='relu')(x)
        x = layers.Conv2D(filters, 3, padding='same', activation='relu')(x)
        return x

    def attention_block(x, g, inter_channels):
        theta_x = layers.Conv2D(inter_channels, 2, strides=2, padding='same')(x)
        phi_g   = layers.Conv2D(inter_channels, 1, strides=1, padding='same')(g)
        add_xg  = layers.add([theta_x, phi_g])
        act_xg  = layers.Activation('relu')(add_xg)
        psi     = layers.Conv2D(1, 1, padding='same')(act_xg)
        psi     = layers.Activation('sigmoid')(psi)
        psi_up  = layers.Conv2DTranspose(1, 2, strides=2, padding='same')(psi)
        return layers.multiply([x, psi_up])

    inp = layers.Input(input_shape)
    # encoder
    c1 = conv_block(inp, 64); p1 = layers.MaxPooling2D(2)(c1)   # (None, 64, 64, 64)
    c2 = conv_block(p1, 128); p2 = layers.MaxPooling2D(2)(c2)   # (None, 32, 32, 128)
    c3 = conv_block(p2, 256); p3 = layers.MaxPooling2D(2)(c3)   # (None, 16, 16, 256)
    c4 = conv_block(p3, 512)                                   # (None, 16, 16, 512)

    # decoder (Attention)
    g3   = layers.Conv2D(256, 1, activation='relu')(c4)
    att3 = attention_block(c3, g3, 256)
    u3   = layers.Conv2DTranspose(256, 2, strides=2, padding='same')(c4)  # 16->32
    u3   = layers.concatenate([u3, att3], axis=-1)
    cc3  = conv_block(u3, 256)   # (None, 32, 32, 256)

    # ============= 多尺度 (MS) 特征融合示例 =============
    # c1 => (None, 128,128,64), c2 => (None,64,64,128), c3 => (None,32,32,256)
    # 我们想把 c1, c2 下采样到 32x32，再与 cc3 拼接
    ms2 = layers.Conv2D(256, 3, strides=2, padding='same')(c2)  # 64->32
    ms3 = layers.Conv2D(256, 3, strides=4, padding='same')(c1)  # 128->32
    # 现在 ms2, ms3, cc3 全部是 (None, 32,32, 256)
    ms_cat = layers.concatenate([cc3, ms2, ms3], axis=-1)  # (None, 32,32, 256*3=768)
    ms_cat = layers.Conv2D(256, 1, activation='relu')(ms_cat)   # 融合后再压回 256

    # 继续decoder
    g2   = layers.Conv2D(128, 1, activation='relu')(ms_cat)
    att2 = attention_block(c2, g2, 128)
    u2   = layers.Conv2DTranspose(128, 2, strides=2, padding='same')(ms_cat)  # 32->64
    u2   = layers.concatenate([u2, att2], axis=-1)
    cc2  = conv_block(u2, 128)  # (None, 64,64,128)

    g1   = layers.Conv2D(64, 1, activation='relu')(cc2)
    att1 = attention_block(c1, g1, 64)
    u1   = layers.Conv2DTranspose(64, 2, strides=2, padding='same')(cc2)  # 64->128
    u1   = layers.concatenate([u1, att1], axis=-1)
    cc1  = conv_block(u1, 64)

    outp = layers.Conv2D(out_channels, 1, activation='sigmoid')(cc1)
    return models.Model(inp, outp, name='MultiScaleAttentionUNet')



###############################################################################
# 3. ViT结构上的实验修改（Experiment D/E）
###############################################################################
class Patches(layers.Layer):
    def __init__(self, patch_size=16, **kwargs):
        super().__init__(**kwargs)
        self.patch_size = patch_size
    def call(self, images):
        batch_size = tf.shape(images)[0]
        patches = tf.image.extract_patches(
            images=images,
            sizes=[1, self.patch_size, self.patch_size, 1],
            strides=[1, self.patch_size, self.patch_size, 1],
            rates=[1,1,1,1],
            padding='VALID'
        )
        patch_dims = patches.shape[-1]
        patches = tf.reshape(patches, [batch_size, -1, patch_dims])
        return patches

class PatchEncoder1D(layers.Layer):
    """
    与原脚本相同的做法：1D顺序embedding
    """
    def __init__(self, num_patches, projection_dim, **kwargs):
        super().__init__(**kwargs)
        self.num_patches = num_patches
        self.projection  = layers.Dense(units=projection_dim)
        self.position_embedding = layers.Embedding(
            input_dim=num_patches,
            output_dim=projection_dim
        )
    def call(self, patches):
        positions = tf.range(start=0, limit=self.num_patches, delta=1)
        encoded   = self.projection(patches) + self.position_embedding(positions)
        return encoded

class PatchEncoder2D(layers.Layer):
    """
    Experiment D: 使用可学习的 2D 位置编码。
    做法：假设 num_patches = Nx * Ny (行方向 N, 列方向 M)。
    则先把patches reshape回 (batch, Nx, Ny, embed_dim)，再加 (Nx, Ny, embed_dim) 的可学习pos矩阵。
    简化示例：
    """
    def __init__(self, grid_size_x, grid_size_y, projection_dim, **kwargs):
        super().__init__(**kwargs)
        self.grid_size_x = grid_size_x
        self.grid_size_y = grid_size_y
        self.projection_dim = projection_dim
        # 2D可学习位置向量
        self.pos_embed = self.add_weight("pos_embed", shape=(1, grid_size_x, grid_size_y, projection_dim),
                                         initializer='random_normal')
    def call(self, x):
        # x: (batch, Nx*Ny, embed_dim)
        B = tf.shape(x)[0]
        x2d = tf.reshape(x, (B, self.grid_size_x, self.grid_size_y, self.projection_dim))
        x2d = x2d + self.pos_embed
        x_flat = tf.reshape(x2d, (B, -1, self.projection_dim))
        return x_flat

def mlp_transformer_block(x, hidden_units, dropout_rate, out_dim):
    for units in hidden_units:
        x = layers.Dense(units, activation=tf.nn.gelu)(x)
        x = layers.Dropout(dropout_rate)(x)
    x = layers.Dense(out_dim)(x)
    return x

def build_simple_vit_experiment(
    input_shape=(96,96,5),
    patch_size=16,
    num_heads=4,
    embed_dim=128,
    ff_dim=256,
    transformer_layers=3,
    num_classes=3,
    use_2d_embed=False,
    refine_regression=False
):
    """
    Experiment D: use_2d_embed=True 则使用 2D 位置编码
    Experiment E: refine_regression=True 则在回归头增加额外的网络(MLP)
    """
    inp = layers.Input(shape=input_shape)

    # 分patch
    patches_layer = Patches(patch_size)
    patches = patches_layer(inp)

    num_patches_x = input_shape[0] // patch_size
    num_patches_y = input_shape[1] // patch_size
    num_patches   = num_patches_x * num_patches_y

    # 选择合适的PatchEncoder
    if use_2d_embed:
        projection = layers.Dense(units=embed_dim)
        x_proj = projection(patches)  # shape=(B, num_patches, embed_dim)
        encoder_2d = PatchEncoder2D(num_patches_x, num_patches_y, embed_dim)
        x_enc = encoder_2d(x_proj)
    else:
        encoder_1d = PatchEncoder1D(num_patches, embed_dim)
        x_enc = encoder_1d(patches)

    # Transformer
    for _ in range(transformer_layers):
        x1 = layers.LayerNormalization(epsilon=1e-6)(x_enc)
        attention_output = layers.MultiHeadAttention(
            num_heads=num_heads, key_dim=embed_dim, dropout=0.1
        )(x1, x1)
        x2 = layers.Add()([attention_output, x_enc])

        x3 = layers.LayerNormalization(epsilon=1e-6)(x2)
        x3 = mlp_transformer_block(x3, [ff_dim], 0.1, embed_dim)
        x_enc = layers.Add()([x3, x2])

    rep = layers.LayerNormalization(epsilon=1e-6)(x_enc)
    rep = layers.GlobalAveragePooling1D()(rep)
    rep = layers.Dropout(0.5)(rep)

    # 分类输出
    cls_out = layers.Dense(num_classes, name='patch_cls')(rep)

    # 回归输出
    if refine_regression:
        # 再加一个小MLP
        dense_reg = layers.Dense(ff_dim, activation='relu')(rep)
        dense_reg = layers.Dropout(0.3)(dense_reg)
        pos_out = layers.Dense(2, activation='sigmoid', name='patch_pos')(dense_reg)
    else:
        pos_out = layers.Dense(2, activation='sigmoid', name='patch_pos')(rep)

    return models.Model(inp, [cls_out, pos_out], name="CustomViT_Exp")


def build_infer_patches(X_data, Y_data, Sinfo_data, T):
    patch_imgs, patch_cls, patch_pos = [], [], []
    for i in range(len(X_data)):
        # 合并此样本多帧mask，找连通域
        union_mask = np.max(Y_data[i], axis=-1).astype(np.uint8)
        num_l, _, stats, centroids = cv2.connectedComponentsWithStats(union_mask, connectivity=8)

        # 与源信息匹配
        for s in Sinfo_data[i]:
            stype_id = s[1]  # 0/1/2
            x0, y0 = s[2], s[3]
            # 找与该源最近的连通域
            best_lb, best_d = None, 1e9
            for lb in range(1, num_l):
                cx, cy = centroids[lb]
                dd = (cy - x0)**2 + (cx - y0)**2
                if dd < best_d:
                    best_d = dd
                    best_lb = lb
            if best_lb is None:
                continue

            x2 = stats[best_lb, cv2.CC_STAT_LEFT]
            y2 = stats[best_lb, cv2.CC_STAT_TOP]
            w2 = stats[best_lb, cv2.CC_STAT_WIDTH]
            h2 = stats[best_lb, cv2.CC_STAT_HEIGHT]
            if w2 < 2 or h2 < 2:
                continue

            # 提取该连通域的子图并Resize到 (96,96,T)
            sub_img = X_data[i, y2:y2+h2, x2:x2+w2, :]
            sub_res = np.zeros((96, 96, T), dtype=np.float32)
            for t_ in range(T):
                tmp = cv2.resize(sub_img[..., t_], (96, 96))
                mm, ss = tmp.mean(), tmp.std() + 1e-6
                tmp = (tmp - mm) / ss
                sub_res[..., t_] = tmp

            # 计算归一化后的位置偏移
            roff = (x0 - y2) / (h2 + 1e-6)
            coff = (y0 - x2) / (w2 + 1e-6)

            patch_imgs.append(sub_res)
            patch_cls.append(stype_id)
            patch_pos.append([roff, coff])

    return (
        np.array(patch_imgs, dtype=np.float32),
        np.array(patch_cls,  dtype=np.int32),
        np.array(patch_pos,  dtype=np.float32)
    )



###############################################################################
# 4. 实验跑法：run_experiment() + 记录结果到 JSON
###############################################################################
from datetime import datetime
def run_experiment(experiment_name,
                   generator_type="baseline",
                   vit_2d_embed=False,
                   vit_refine_reg=False,
                   do_random_rotation=False):
    """
    - experiment_name: 字符串名称，用于保存json的标记
    - generator_type: ["baseline", "resunet", "multiscale"]
    - vit_2d_embed: bool, 是否使用 2D position embedding
    - vit_refine_reg: bool, 是否在回归头加MLP
    - do_random_rotation: bool, 是否在数据增强时添加随机旋转

    返回: 一个dict，包含 cGAN的IoU、Dice，以及ViT分类准确度、回归RMSE等指标
    """
    # ============ 1) 数据准备 ============
    # 简化起见，这里只生成一小份数据，如 300 train, 100 test
    # 若要更稳定的结果可增大数据量
    num_total = 3000
    grid_size = 128
    T = 5
    idx_split = 2100

    X_all, Y_all, Sinfo_all = create_dataset_dynamic(
        num_samples=num_total,
        grid_size=grid_size,
        T=T,
        do_augment=do_random_rotation  # 是否使用随机旋转
    )
    X_train, Y_train = X_all[:idx_split], Y_all[:idx_split]
    X_test,  Y_test  = X_all[idx_split:], Y_all[idx_split:]
    Sinfo_tr, Sinfo_ts = Sinfo_all[:idx_split], Sinfo_all[idx_split:]

    # ============ 2) 构建 cGAN (生成器+判别器) ============
    # baseline / resunet / multiscale
    if generator_type == "resunet":
        generator = build_resunet_generator((grid_size,grid_size,T), out_channels=T)
    elif generator_type == "multiscale":
        generator = build_multiscale_attention_unet((grid_size,grid_size,T), out_channels=T)
    else:
        # baseline 就用原先的 attention_unet
        from tensorflow.keras.models import load_model
        from tensorflow.keras.layers import Input
        # 这里直接用我们之前定义的
        # build_attention_unet(input_shape, out_channels)
        # 为了简洁，直接内嵌：
        def build_attention_unet(input_shape=(128,128,1), out_channels=1):
            inp = layers.Input(input_shape)
            c1 = layers.Conv2D(64, 3, padding='same', activation='relu')(inp)
            c1 = layers.Conv2D(64, 3, padding='same', activation='relu')(c1)
            p1 = layers.MaxPooling2D(2)(c1)

            c2 = layers.Conv2D(128, 3, padding='same', activation='relu')(p1)
            c2 = layers.Conv2D(128, 3, padding='same', activation='relu')(c2)
            p2 = layers.MaxPooling2D(2)(c2)

            c3 = layers.Conv2D(256, 3, padding='same', activation='relu')(p2)
            c3 = layers.Conv2D(256, 3, padding='same', activation='relu')(c3)
            p3 = layers.MaxPooling2D(2)(c3)

            c4 = layers.Conv2D(512, 3, padding='same', activation='relu')(p3)
            c4 = layers.Conv2D(512, 3, padding='same', activation='relu')(c4)

            def attention_block(x, g, inter_channels):
                theta_x = layers.Conv2D(inter_channels, 2, strides=2, padding='same')(x)
                phi_g   = layers.Conv2D(inter_channels, 1, strides=1, padding='same')(g)
                add_xg  = layers.add([theta_x, phi_g])
                act_xg  = layers.Activation('relu')(add_xg)
                psi     = layers.Conv2D(1, 1, padding='same')(act_xg)
                psi     = layers.Activation('sigmoid')(psi)
                psi_up  = layers.Conv2DTranspose(1, 2, strides=2, padding='same')(psi)
                return layers.multiply([x, psi_up])

            g3   = layers.Conv2D(256, 1, activation='relu')(c4)
            att3 = attention_block(c3, g3, 256)
            u3   = layers.Conv2DTranspose(256, 2, strides=2, padding='same')(c4)
            u3   = layers.concatenate([u3, att3], axis=-1)
            cc3  = layers.Conv2D(256, 3, padding='same', activation='relu')(u3)
            cc3  = layers.Conv2D(256, 3, padding='same', activation='relu')(cc3)

            g2   = layers.Conv2D(128, 1, activation='relu')(cc3)
            att2 = attention_block(c2, g2, 128)
            u2   = layers.Conv2DTranspose(128, 2, strides=2, padding='same')(cc3)
            u2   = layers.concatenate([u2, att2], axis=-1)
            cc2  = layers.Conv2D(128, 3, padding='same', activation='relu')(u2)
            cc2  = layers.Conv2D(128, 3, padding='same', activation='relu')(cc2)

            g1   = layers.Conv2D(64, 1, activation='relu')(cc2)
            att1 = attention_block(c1, g1, 64)
            u1   = layers.Conv2DTranspose(64, 2, strides=2, padding='same')(cc2)
            u1   = layers.concatenate([u1, att1], axis=-1)
            cc1  = layers.Conv2D(64, 3, padding='same', activation='relu')(u1)
            cc1  = layers.Conv2D(64, 3, padding='same', activation='relu')(cc1)

            outp = layers.Conv2D(out_channels, 1, activation='sigmoid')(cc1)
            return models.Model(inp, outp, name='AttentionUNet')

        generator = build_attention_unet((grid_size, grid_size, T), out_channels=T)

    discriminator = build_patchgan_discriminator((grid_size, grid_size, 2*T))
    class MagneticDistortCGAN(tf.keras.Model):
        def __init__(self, generator, discriminator, lambda_seg=12.0, **kwargs):
            super().__init__(**kwargs)
            self.generator     = generator
            self.discriminator = discriminator
            self.lambda_seg    = lambda_seg
        def compile(self, g_opt, d_opt, seg_loss_fn, adv_loss_fn):
            super().compile()
            self.g_opt       = g_opt
            self.d_opt       = d_opt
            self.seg_loss_fn = seg_loss_fn
            self.adv_loss_fn = adv_loss_fn
        def train_step(self, data):
            x, y = data
            with tf.GradientTape() as gtape, tf.GradientTape() as dtape:
                fake_mask = self.generator(x, training=True)
                real_pair = tf.concat([x, y], axis=-1)
                fake_pair = tf.concat([x, fake_mask], axis=-1)
                real_logit = self.discriminator(real_pair, training=True)
                fake_logit = self.discriminator(fake_pair, training=True)
                g_adv = self.adv_loss_fn(tf.ones_like(fake_logit), fake_logit)
                g_seg = self.seg_loss_fn(y, fake_mask) * self.lambda_seg
                g_loss = g_adv + g_seg
                d_real = self.adv_loss_fn(tf.ones_like(real_logit)*0.9, real_logit)
                d_fake = self.adv_loss_fn(tf.zeros_like(fake_logit), fake_logit)
                d_loss = 0.5*(d_real + d_fake)
            g_grad = gtape.gradient(g_loss, self.generator.trainable_variables)
            self.g_opt.apply_gradients(zip(g_grad, self.generator.trainable_variables))
            d_grad = dtape.gradient(d_loss, self.discriminator.trainable_variables)
            self.d_opt.apply_gradients(zip(d_grad, self.discriminator.trainable_variables))
            return {"g_loss": g_loss, "g_adv": g_adv, "g_seg": g_seg, "d_loss": d_loss}

    cgan = MagneticDistortCGAN(generator, discriminator, lambda_seg=12.0)
    cgan.compile(
        g_opt=Adam(1e-4, beta_1=0.5),
        d_opt=Adam(1e-4, beta_1=0.5),
        seg_loss_fn=combined_bce_dice_loss,
        adv_loss_fn=BinaryCrossentropy(from_logits=True)
    )

    # 训练 cGAN（这里epochs少一点演示）
    iou_val = cgan.fit(X_train, Y_train, epochs=200, batch_size=4, verbose=1)
    dice_val = preds_test = generator.predict(X_test)

    # 计算测试集 IoU 与 Dice
    def compute_iou_np(y_true, y_pred):
        y_true_bin = (y_true > 0.5).astype(np.float32)
        y_pred_bin = (y_pred > 0.5).astype(np.float32)
        intersection = np.sum(y_true_bin * y_pred_bin)
        union = np.sum(y_true_bin) + np.sum(y_pred_bin) - intersection
        iou = (intersection + 1e-6) / (union + 1e-6)
        return iou
    iou_val = compute_iou_np(Y_test, preds_test)
    def compute_dice_np(y_true, y_pred):
        y_true_bin = (y_true > 0.5).astype(np.float32)
        y_pred_bin = (y_pred > 0.5).astype(np.float32)
        intersection = np.sum(y_true_bin * y_pred_bin)
        den = np.sum(y_true_bin) + np.sum(y_pred_bin)
        dice = (2*intersection+1e-6)/(den+1e-6)
        return dice
    dice_val = compute_dice_np(Y_test, preds_test)

    # ============ 3) 训练 ViT =============
    # 提取训练集连通域 -> patch_imgs, patch_cls, patch_pos
    patch_imgs, patch_cls, patch_pos = [], [], []
    for i in range(len(X_train)):
        union_mask = np.max(Y_train[i], axis=-1).astype(np.uint8)
        num_l, _, stats, centroids = cv2.connectedComponentsWithStats(union_mask, connectivity=8)
        # 每个源找最近连通域
        for s in Sinfo_tr[i]:
            stype_id = s[1]  # 0/1/2
            x0, y0 = s[2], s[3]
            best_lb, best_d = None, 1e9
            for lb in range(1, num_l):
                cx, cy = centroids[lb]
                dd = (cy - x0)**2 + (cx - y0)**2
                if dd < best_d:
                    best_d = dd
                    best_lb = lb
            if best_lb is None:
                continue
            x2 = stats[best_lb, cv2.CC_STAT_LEFT]
            y2 = stats[best_lb, cv2.CC_STAT_TOP]
            w2 = stats[best_lb, cv2.CC_STAT_WIDTH]
            h2 = stats[best_lb, cv2.CC_STAT_HEIGHT]
            if w2 < 2 or h2 < 2:
                continue
            sub_img = X_train[i, y2:y2+h2, x2:x2+w2, :]  # shape=(h2,w2,T)
            sub_res = np.zeros((96, 96, T), dtype=np.float32)
            for t_ in range(T):
                tmp = cv2.resize(sub_img[..., t_], (96, 96))
                mm, ss = tmp.mean(), tmp.std() + 1e-6
                tmp = (tmp - mm)/ss
                sub_res[..., t_] = tmp
            roff = (x0 - y2) / (h2+1e-6)
            coff = (y0 - x2) / (w2+1e-6)
            patch_imgs.append(sub_res)
            patch_cls.append(stype_id)
            patch_pos.append([roff, coff])
    patch_imgs = np.array(patch_imgs, dtype=np.float32)
    patch_cls  = np.array(patch_cls, dtype=np.int32)
    patch_pos  = np.array(patch_pos, dtype=np.float32)

    # 构建 ViT
    vit_model = build_simple_vit_experiment(
        input_shape=(96,96,T),
        patch_size=16,
        num_heads=4,
        embed_dim=128,
        ff_dim=256,
        transformer_layers=3,
        num_classes=3,
        use_2d_embed=vit_2d_embed,      # D
        refine_regression=vit_refine_reg # E
    )
    vit_model.compile(
        optimizer=Adam(1e-4),
        loss={
            "patch_cls": tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
            "patch_pos": tf.keras.losses.MeanSquaredError()
        },
        loss_weights={"patch_cls": 2.0, "patch_pos": 0.05},
        metrics={"patch_cls": "accuracy"}
    )

    # 简单拆分一下训练/验证
    idxs = np.arange(len(patch_imgs))
    np.random.shuffle(idxs)
    spn = int(0.7*len(idxs))
    id_tr, id_vl = idxs[:spn], idxs[spn:]
    vit_history = vit_model.fit(
        patch_imgs[id_tr],
        {"patch_cls": patch_cls[id_tr], "patch_pos": patch_pos[id_tr]},
        validation_data=(
            patch_imgs[id_vl],
            {"patch_cls": patch_cls[id_vl], "patch_pos": patch_pos[id_vl]}
        ),
        epochs=100, batch_size=8, verbose=1
    )
    # 测试集上做分类/回归评估
    # 先在测试集也提取 patch, 但此处仅演示, 也可对Sinfo_ts逐个做同样步骤
    # ----------------------------------------------------------------
    # ========= 4) 重新生成一份推理数据，用于最终指标计算 =========
    X_infer, Y_infer, Sinfo_infer = create_dataset_dynamic(
        num_samples=1000,         # 自行设定多少条推理数据
        grid_size=grid_size,
        T=T,
        do_augment=False         # 视情况决定是否要旋转/翻转
    )

    # 4.1 cGAN在推理数据上的分割指标
    preds_infer = generator.predict(X_infer)
    iou_val_final  = compute_iou_np(Y_infer, preds_infer)
    dice_val_final = compute_dice_np(Y_infer, preds_infer)

    # 4.2 ViT在推理数据上的分类与回归指标
    patch_imgs_infer, patch_cls_infer, patch_pos_infer = \
        build_infer_patches(X_infer, Y_infer, Sinfo_infer, T)

    if len(patch_imgs_infer) > 0:
        vit_preds_infer = vit_model.predict(patch_imgs_infer, verbose=0)
        pred_cls_logits_infer = vit_preds_infer[0]
        pred_cls_id_infer = np.argmax(pred_cls_logits_infer, axis=1)
        cls_acc_infer = (pred_cls_id_infer == patch_cls_infer).mean()

        pred_pos_infer = vit_preds_infer[1]
        rmse_infer = np.sqrt(np.mean((pred_pos_infer - patch_pos_infer)**2))
    else:
        cls_acc_infer = 0.0
        rmse_infer = 0.0

    return {
        "experiment_name": experiment_name,
        "generator_type": generator_type,
        "vit_2d_embed": vit_2d_embed,
        "vit_refine_reg": vit_refine_reg,
        "do_random_rotation": do_random_rotation,

        # 最终指标改为在推理数据上测
        "iou":  float(iou_val_final),
        "dice": float(dice_val_final),
        "cls_acc": float(cls_acc_infer),
        "pos_rmse": float(rmse_infer),

        # 模型本身依然可以返回，供后续可视化或其他用途
        "generator": generator,
        "vit_model": vit_model
    }

###############################################################################
# 5. 主流程：分别运行 5 个实验 + Baseline，对比并保存到 JSON
###############################################################################
def main_experiments():
    import os
    import json
    from datetime import datetime

    # 如果没有输出文件夹，就先创建
    os.makedirs("outputs", exist_ok=True)

    results = []

    # --------------------- 1) baseline ---------------------
    baseline_res = run_experiment(
        experiment_name="baseline",
        generator_type="baseline",
        vit_2d_embed=False,
        vit_refine_reg=False,
        do_random_rotation=False
    )
    results.append(baseline_res)

    # 做可视化：再额外生成一批小数据
    outdir_base = "outputs/baseline"
    os.makedirs(outdir_base, exist_ok=True)
    X_vis, Y_vis, Sinfo_vis = create_dataset_dynamic(
        num_samples=20,  # 仅为演示，想要更多可视化样本可增大
        grid_size=128,
        T=5,
        do_augment=False
    )
    preds_test = baseline_res["generator"].predict(X_vis)

    visualize_output_1(X_vis, Y_vis, Sinfo_vis,
                       out_dir=os.path.join(outdir_base, "output_1"),
                       count=10)
    visualize_output_2(X_vis, Y_vis, preds_test, Sinfo_vis,
                       out_dir=os.path.join(outdir_base, "output_2"),
                       count=10)
    visualize_output_3(X_vis, Y_vis, Sinfo_vis,
                       baseline_res["vit_model"],
                       out_dir=os.path.join(outdir_base, "output_3"),
                       count=10)

    # --------------------- 2) Experiment A ---------------------
    expA_res = run_experiment(
        experiment_name="ExperimentA_ResUNet",
        generator_type="resunet",
        vit_2d_embed=False,
        vit_refine_reg=False,
        do_random_rotation=False
    )
    results.append(expA_res)

    outdir_A = "outputs/ExperimentA_ResUNet"
    os.makedirs(outdir_A, exist_ok=True)
    XA_vis, YA_vis, SinfoA_vis = create_dataset_dynamic(
        num_samples=20,
        grid_size=128,
        T=5,
        do_augment=False
    )
    predA_test = expA_res["generator"].predict(XA_vis)

    visualize_output_1(XA_vis, YA_vis, SinfoA_vis,
                       out_dir=os.path.join(outdir_A, "output_1"),
                       count=10)
    visualize_output_2(XA_vis, YA_vis, predA_test, SinfoA_vis,
                       out_dir=os.path.join(outdir_A, "output_2"),
                       count=10)
    visualize_output_3(XA_vis, YA_vis, SinfoA_vis,
                       expA_res["vit_model"],
                       out_dir=os.path.join(outdir_A, "output_3"),
                       count=10)

    # --------------------- 3) Experiment B ---------------------
    expB_res = run_experiment(
        experiment_name="ExperimentB_MultiScaleAttention",
        generator_type="multiscale",
        vit_2d_embed=False,
        vit_refine_reg=False,
        do_random_rotation=False
    )
    results.append(expB_res)

    outdir_B = "outputs/ExperimentB_MultiScaleAttention"
    os.makedirs(outdir_B, exist_ok=True)
    XB_vis, YB_vis, SinfoB_vis = create_dataset_dynamic(
        num_samples=20,
        grid_size=128,
        T=5,
        do_augment=False
    )
    predB_test = expB_res["generator"].predict(XB_vis)

    visualize_output_1(XB_vis, YB_vis, SinfoB_vis,
                       out_dir=os.path.join(outdir_B, "output_1"),
                       count=10)
    visualize_output_2(XB_vis, YB_vis, predB_test, SinfoB_vis,
                       out_dir=os.path.join(outdir_B, "output_2"),
                       count=10)
    visualize_output_3(XB_vis, YB_vis, SinfoB_vis,
                       expB_res["vit_model"],
                       out_dir=os.path.join(outdir_B, "output_3"),
                       count=10)

    # --------------------- 4) Experiment C ---------------------
    expC_res = run_experiment(
        experiment_name="ExperimentC_RandRotation",
        generator_type="baseline",
        vit_2d_embed=False,
        vit_refine_reg=False,
        do_random_rotation=True
    )
    results.append(expC_res)

    outdir_C = "outputs/ExperimentC_RandRotation"
    os.makedirs(outdir_C, exist_ok=True)
    XC_vis, YC_vis, SinfoC_vis = create_dataset_dynamic(
        num_samples=20,
        grid_size=128,
        T=5,
        do_augment=False
    )
    predC_test = expC_res["generator"].predict(XC_vis)

    visualize_output_1(XC_vis, YC_vis, SinfoC_vis,
                       out_dir=os.path.join(outdir_C, "output_1"),
                       count=10)
    visualize_output_2(XC_vis, YC_vis, predC_test, SinfoC_vis,
                       out_dir=os.path.join(outdir_C, "output_2"),
                       count=10)
    visualize_output_3(XC_vis, YC_vis, SinfoC_vis,
                       expC_res["vit_model"],
                       out_dir=os.path.join(outdir_C, "output_3"),
                       count=10)

    # --------------------- 5) Experiment D ---------------------
    expD_res = run_experiment(
        experiment_name="ExperimentD_ViT2DPos",
        generator_type="baseline",
        vit_2d_embed=True,
        vit_refine_reg=False,
        do_random_rotation=False
    )
    results.append(expD_res)

    outdir_D = "outputs/ExperimentD_ViT2DPos"
    os.makedirs(outdir_D, exist_ok=True)
    XD_vis, YD_vis, SinfoD_vis = create_dataset_dynamic(
        num_samples=20,
        grid_size=128,
        T=5,
        do_augment=False
    )
    predD_test = expD_res["generator"].predict(XD_vis)

    visualize_output_1(XD_vis, YD_vis, SinfoD_vis,
                       out_dir=os.path.join(outdir_D, "output_1"),
                       count=10)
    visualize_output_2(XD_vis, YD_vis, predD_test, SinfoD_vis,
                       out_dir=os.path.join(outdir_D, "output_2"),
                       count=10)
    visualize_output_3(XD_vis, YD_vis, SinfoD_vis,
                       expD_res["vit_model"],
                       out_dir=os.path.join(outdir_D, "output_3"),
                       count=10)

    # --------------------- 6) Experiment E ---------------------
    expE_res = run_experiment(
        experiment_name="ExperimentE_ViTRefineReg",
        generator_type="baseline",
        vit_2d_embed=False,
        vit_refine_reg=True,
        do_random_rotation=False
    )
    results.append(expE_res)

    outdir_E = "outputs/ExperimentE_ViTRefineReg"
    os.makedirs(outdir_E, exist_ok=True)
    XE_vis, YE_vis, SinfoE_vis = create_dataset_dynamic(
        num_samples=20,
        grid_size=128,
        T=5,
        do_augment=False
    )
    predE_test = expE_res["generator"].predict(XE_vis)

    visualize_output_1(XE_vis, YE_vis, SinfoE_vis,
                       out_dir=os.path.join(outdir_E, "output_1"),
                       count=10)
    visualize_output_2(XE_vis, YE_vis, predE_test, SinfoE_vis,
                       out_dir=os.path.join(outdir_E, "output_2"),
                       count=10)
    visualize_output_3(XE_vis, YE_vis, SinfoE_vis,
                       expE_res["vit_model"],
                       out_dir=os.path.join(outdir_E, "output_3"),
                       count=10)

    # --------------------- 汇总并保存 JSON ---------------------
    summary_results = []
    for r in results:
        summary_results.append({
            "experiment_name": r["experiment_name"],
            "generator_type": r["generator_type"],
            "vit_2d_embed": r["vit_2d_embed"],
            "vit_refine_reg": r["vit_refine_reg"],
            "do_random_rotation": r["do_random_rotation"],
            "iou": r["iou"],
            "dice": r["dice"],
            "cls_acc": r["cls_acc"],
            "pos_rmse": r["pos_rmse"]
        })

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    save_path = f"outputs/experiment_results_{ts}.json"
    with open(save_path, "w") as f:
        json.dump(summary_results, f, indent=2)

    print("[INFO] All experiments done! Results saved to", save_path)



if __name__ == "__main__":
    main_experiments()
